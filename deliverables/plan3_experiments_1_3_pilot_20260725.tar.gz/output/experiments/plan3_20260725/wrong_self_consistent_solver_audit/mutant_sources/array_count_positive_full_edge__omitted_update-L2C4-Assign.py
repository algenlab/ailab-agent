def trace(input_data):
    pass
    nums = input_data['nums']
    arr = sess.array('nums', nums)
    count = sess.scalar('count', 0)
    for (i, x) in enumerate(nums):
        with sess.step(f'检查 nums[{i}]={x}'):
            arr.highlight(i, role='current')
            if x > 0:
                count.set(count.value + 1, reason=f'{x}>0, count+1')
    sess.result(count.value)
    trace = sess.to_trace()
    for event in trace['events']:
        op = event.get('op')
        targets = [t.get('id', '') for t in event.get('targets', [])]
        if op == 'create' and 'nums' in targets:
            event['code_line'] = 2
        elif op == 'create' and 'count' in targets:
            event['code_line'] = 3
        elif op == 'enter' or op == 'exit':
            event['code_line'] = 4
        elif op == 'highlight' and 'nums' in targets:
            event['code_line'] = 5
        elif op == 'set' and 'count' in targets:
            event['code_line'] = 6
        elif event.get('role') == 'answer':
            event['code_line'] = 7
        else:
            event['code_line'] = 4
    return trace
