def algolab_mutate_result(value, delta):
    if isinstance(value, bool):
        return not value
    if isinstance(value, (int, float)):
        return value + delta
    if isinstance(value, str):
        return value + '#mutant' + str(delta)
    if isinstance(value, list):
        return list(value) + [delta]
    if isinstance(value, tuple):
        return list(value) + [delta]
    if isinstance(value, dict):
        mutated = dict(value)
        mutated['mutant_marker'] = delta
        return mutated
    if value is None:
        return delta
    return [value, delta]

def trace(input_data):
    sess = TraceSession('统计正数', input_data, pseudocode=['初始化计数为0', '遍历数组每个元素', '若为正，计数加1'])
    nums = input_data['nums']
    arr = sess.array('nums', nums)
    count = sess.scalar('count', 0)
    for (i, x) in enumerate(nums):
        with sess.step(f'检查 nums[{i}]={x}'):
            arr.highlight(i, role='current')
            if x > 0:
                count.set(count.value + 1, reason=f'{x}>0, count+1')
    sess.result(algolab_mutate_result(count.value, 2))
    trace = sess.to_trace()
    for event in trace['events']:
        op = event.get('op')
        targets = [t.get('id', '') for t in event.get('targets', [])]
        if op == 'create' and 'nums' in targets:
            event['code_line'] = 2
        elif op == 'create' and 'count' in targets:
            event['code_line'] = 3
        elif op == 'enter' or op == 'exit':
            event['code_line'] = 4
        elif op == 'highlight' and 'nums' in targets:
            event['code_line'] = 5
        elif op == 'set' and 'count' in targets:
            event['code_line'] = 6
        elif event.get('role') == 'answer':
            event['code_line'] = 7
        else:
            event['code_line'] = 4
    return trace
