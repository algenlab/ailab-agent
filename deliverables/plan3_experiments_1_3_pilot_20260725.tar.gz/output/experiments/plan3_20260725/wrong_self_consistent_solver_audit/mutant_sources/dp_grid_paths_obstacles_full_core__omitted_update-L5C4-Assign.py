def trace(input_data):
    sess = TraceSession('不同路径-动态规划', input_data, pseudocode=['初始化dp表', '遍历每个单元格', '障碍格为0，否则累加上方和左方'])
    grid = input_data['grid']
    (m, n) = (len(grid), len(grid[0]))
    pass
    for i in range(m):
        for j in range(n):
            if grid[i][j] == 1:
                title = f'({i},{j}) 障碍'
            elif i == 0 and j == 0:
                title = f'({i},{j}) 起点'
            else:
                title = f'({i},{j}) 计算'
            with sess.step(title):
                dp.highlight((i, j), role='current')
                if grid[i][j] == 1:
                    dp[i, j] = 0
                    sess.note('障碍，路径数为0')
                elif i == 0 and j == 0:
                    dp[i, j] = 1
                    sess.note('起点，路径数为1')
                else:
                    up = dp[i - 1, j] if i > 0 else 0
                    left = dp[i, j - 1] if j > 0 else 0
                    total = up + left
                    dp[i, j] = total
                    sess.note(f'{up} + {left} = {total}')
    answer = dp[m - 1, n - 1]
    sess.result(answer)
    trace = sess.to_trace()
    current_line = 6
    for e in trace['events']:
        op = e.get('op')
        targets = [t.get('id', '') for t in e.get('targets', [])]
        title = e.get('title', '')
        if op == 'enter':
            if '障碍' in title:
                current_line = 8
            elif '起点' in title:
                current_line = 10
            elif '计算' in title:
                current_line = 14
            else:
                current_line = 6
            e['code_line'] = 5
        elif op == 'exit':
            e['code_line'] = 5
        elif op == 'highlight' and 'dp' in targets:
            e['code_line'] = 6
        elif op == 'set' and 'dp' in targets:
            e['code_line'] = current_line
        elif op == 'note':
            e['code_line'] = current_line
        elif op == 'create' and 'dp' in targets:
            e['code_line'] = 4
        elif op == 'answer' and 'answer' in targets:
            e['code_line'] = 15
        else:
            e['code_line'] = 6
    return trace
