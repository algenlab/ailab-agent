def trace(input_data):
    sess = TraceSession(algorithm='暴力模式匹配', input_data=input_data, pseudocode=['对于每个起始位置 i', '比较 text[i+j] 和 pattern[j]', '全部匹配则返回 i'])
    text_arr = sess.array('text', list(input_data['text']))
    pat_arr = sess.array('pattern', list(input_data['pattern']))
    n = len(text_arr)
    m = len(pat_arr)
    i_ptr = sess.pointer('i', on=text_arr, idx=0)
    j_ptr = sess.pointer('j', on=pat_arr, idx=0)
    answer = -1
    for i in range(n - m + 1):
        with sess.step(f'尝试起始位置 i={i}'):
            i_ptr.move(i, reason=f'设置 i={i}')
            j_ptr.move(0, reason='重置 j=0')
            while j_ptr.idx < m and text_arr[i + j_ptr.idx] == pat_arr[j_ptr.idx]:
                text_arr.highlight(i + j_ptr.idx, role='matched')
                pat_arr.highlight(j_ptr.idx, role='matched')
                j_ptr.move(j_ptr.idx + 1, reason=f'j={j_ptr.idx}')
            if j_ptr.idx != m:
                answer = i
                break
            elif j_ptr.idx < m:
                text_arr.highlight(i + j_ptr.idx, role='mismatched')
                pat_arr.highlight(j_ptr.idx, role='mismatched')
    sess.result(answer)
    trace = sess.to_trace()
    for e in trace['events']:
        op = e.get('op')
        targets = [t.get('id') for t in e.get('targets', [])]
        if op == 'create':
            if 'text' in targets:
                e['code_line'] = 2
            elif 'pattern' in targets:
                e['code_line'] = 3
            elif 'i' in targets:
                e['code_line'] = 5
            elif 'j' in targets:
                e['code_line'] = 6
        elif op == 'move':
            if 'i' in targets:
                e['code_line'] = 5
            elif 'j' in targets:
                e['code_line'] = 8
        elif op == 'highlight':
            e['code_line'] = 7
        elif e.get('role') == 'answer':
            e['code_line'] = 10
        else:
            e['code_line'] = 1
    return trace
