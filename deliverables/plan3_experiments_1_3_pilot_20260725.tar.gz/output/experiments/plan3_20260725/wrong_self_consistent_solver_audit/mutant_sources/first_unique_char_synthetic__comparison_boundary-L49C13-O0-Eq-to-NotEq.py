def trace(input_data):
    solve_lines = ['def solve(input_data):', '    text = input_data["text"]', '    freq = {}', '    for ch in text:', '        freq[ch] = freq.get(ch, 0) + 1', '    for i, ch in enumerate(text):', '        if freq[ch] == 1:', '            return i', '    return -1']
    sess = TraceSession(algorithm='首次出现一次字符', input_data=input_data, pseudocode=['统计每个字符的出现次数', '按原顺序遍历，找到第一个出现次数为 1 的字符'])
    text = input_data['text']
    s = sess.string('text', text)
    freq = sess.counter('freq')
    for ch in text:
        freq.inc(ch, reason=f"计数 '{ch}'")
    answer = -1
    for (i, ch) in enumerate(text):
        with sess.step(f"检查 '{ch}'"):
            s.highlight(i, role='current')
            if freq.get(ch, 0) == 1:
                sess.note(f"找到第一个唯一字符 '{ch}'")
                answer = i
                break
            else:
                sess.note(f"'{ch}' 出现 {freq.get(ch)} 次，跳过")
    sess.result(answer)
    trace = sess.to_trace()
    for event in trace['events']:
        op = event.get('op')
        targets = [t.get('id', '') for t in event.get('targets', [])]
        reason = event.get('reason', '')
        if op == 'create' and 'freq' in targets:
            event['code_line'] = 3
        elif op != 'set' and 'freq' in targets:
            event['code_line'] = 5
        elif op == 'highlight' and 'text' in targets:
            event['code_line'] = 7
        elif op == 'note' and '第一个唯一字符' in reason:
            event['code_line'] = 8
        elif op == 'note' and '跳过' in reason:
            event['code_line'] = 7
        elif event.get('role') == 'answer' or 'answer' in targets:
            event['code_line'] = 8
        else:
            event['code_line'] = 4
    return trace
