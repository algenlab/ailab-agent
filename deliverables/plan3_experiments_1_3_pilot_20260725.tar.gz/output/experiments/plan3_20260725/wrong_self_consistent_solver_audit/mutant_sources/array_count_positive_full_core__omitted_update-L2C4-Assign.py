def trace(input_data):
    pass
    nums = sess.array('nums', input_data['nums'])
    count = sess.scalar('count', 0)
    with sess.step('遍历数组'):
        for i in range(len(nums)):
            x = nums[i]
            nums.highlight(i)
            if x > 0:
                count.set(count.value + 1, reason=f'{x} > 0, 计数加1')
            else:
                sess.note(f'{x} 不大于0')
    answer = count.value
    sess.result(answer)
    return sess.to_trace()
