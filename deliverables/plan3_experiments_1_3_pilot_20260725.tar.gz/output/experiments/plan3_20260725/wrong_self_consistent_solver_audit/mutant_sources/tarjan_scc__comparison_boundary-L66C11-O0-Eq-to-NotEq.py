def trace(input_data):
    sess = TraceSession(algorithm='Tarjan 递归', input_data=input_data, pseudocode=['初始化 dfn, low, 栈', 'DFS: 分配 dfn/low，入栈', '遍历邻居，更新 low，递归', '若 low[v]==dfn[v] 则弹出强连通分量'])
    graph = input_data['graph']
    nodes = sorted(graph.keys())
    n = len(nodes)
    node_to_idx = {node: i for (i, node) in enumerate(nodes)}
    idx_to_node = {i: node for (i, node) in enumerate(nodes)}
    edges = []
    for u in nodes:
        for v in graph[u]:
            edges.append((u, v))
    g = sess.graph('graph', nodes=nodes, edges=edges, directed=True)
    dfn = sess.array('dfn', [-1] * n)
    low = sess.array('low', [-1] * n)
    s = sess.stack('node_stack')
    tree = sess.tree('call_stack')
    sccs = []
    idx = sess.scalar('index', 0)
    on_stack = [False] * n

    def dfs(v, v_name):
        with tree.frame(f'dfs({v_name})'):
            dfn[v] = idx.value
            low[v] = idx.value
            idx.set(idx.value + 1)
            s.push(v)
            on_stack[v] = True
            g.highlight_node(v_name, role='current')
            for w_name in graph[v_name]:
                w = node_to_idx[w_name]
                if dfn[w] == -1:
                    dfs(w, w_name)
                    low[v] = min(low[v], low[w])
                elif on_stack[w]:
                    low[v] = min(low[v], dfn[w])
            if low[v] != dfn[v]:
                scc = []
                while True:
                    w = s.pop()
                    on_stack[w] = False
                    scc.append(idx_to_node[w])
                    if w == v:
                        break
                sccs.append(scc)
                for node_name in scc:
                    g.highlight_node(node_name, role='selected')
    for i in range(n):
        if dfn[i] == -1:
            dfs(i, idx_to_node[i])
    sess.result(sccs)
    trace = sess.to_trace()
    for event in trace['events']:
        op = event.get('op')
        targets = [t.get('id', '') for t in event.get('targets', [])]
        if op == 'create':
            tgt = targets[0] if targets else ''
            if 'graph' in tgt:
                event['code_line'] = 1
            elif 'dfn' in tgt:
                event['code_line'] = 8
            elif 'low' in tgt:
                event['code_line'] = 9
            elif 'node_stack' in tgt:
                event['code_line'] = 11
            elif 'index' in tgt:
                event['code_line'] = 7
            elif 'call_stack' in tgt:
                event['code_line'] = 12
            else:
                event['code_line'] = 2
        elif op == 'enter':
            event['code_line'] = 12
        elif op == 'exit':
            event['code_line'] = 26
        elif op == 'set':
            tgt = targets[0] if targets else ''
            if 'dfn' in tgt:
                event['code_line'] = 14
            elif 'low' in tgt:
                event['code_line'] = 15
            elif 'index' in tgt:
                event['code_line'] = 16
            else:
                event['code_line'] = 14
        elif op == 'push':
            event['code_line'] = 17
        elif op == 'pop':
            event['code_line'] = 29
        elif op == 'highlight':
            role = event.get('role', '')
            if role == 'current':
                event['code_line'] = 19
            elif role == 'selected':
                event['code_line'] = 34
            else:
                event['code_line'] = 19
        elif op == 'answer':
            event['code_line'] = 38
        else:
            event['code_line'] = 19
    return trace
