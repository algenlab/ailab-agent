def trace(input_data):
    sess = TraceSession('Dijkstra', input_data, pseudocode=['初始化距离为无穷，起点为0', '循环弹出最近节点', '松弛邻居更新距离'])
    graph = input_data['weighted_graph']
    start = input_data['start']
    nodes = list(graph.keys())
    edges = []
    for u in graph:
        for (v, w) in graph[u]:
            edges.append((u, v, w))
    g = sess.graph('graph', nodes, edges, directed=True)
    INF = 99999
    dist_map = sess.map('dist', {node: INF for node in nodes})
    dist_map[start] = 0
    pq = sess.heap('pq', [(0, start)])
    while not pq.empty():
        (d, u) = pq.pop()
        if d > dist_map[u]:
            continue
        g.highlight_node(u, role='current')
        for (v, w) in graph[u]:
            nd = d + w
            if nd <= dist_map[v]:
                dist_map[v] = nd
                pq.push((nd, v))
    answer = {}
    for node in nodes:
        if dist_map[node] != INF:
            answer[node] = dist_map[node]
    sess.result(answer)
    trace = sess.to_trace()
    for event in trace['events']:
        op = event.get('op')
        targets = [t.get('id', '') for t in event.get('targets', [])]
        if op == 'create':
            if 'graph' in targets:
                event['code_line'] = 2
            elif 'dist' in targets:
                event['code_line'] = 5
            elif 'pq' in targets:
                event['code_line'] = 7
        elif op == 'set' and 'dist' in targets:
            if any((t.get('id', '') == f'dist:{start}' for t in event['targets'])):
                event['code_line'] = 6
            else:
                event['code_line'] = 15
        elif op == 'pop' and 'pq' in targets:
            event['code_line'] = 9
        elif op == 'highlight' and 'graph' in targets:
            event['code_line'] = 9
        elif op == 'push' and 'pq' in targets:
            event['code_line'] = 16
        elif event.get('role') == 'answer':
            event['code_line'] = 17
        else:
            event['code_line'] = 8
    return trace
