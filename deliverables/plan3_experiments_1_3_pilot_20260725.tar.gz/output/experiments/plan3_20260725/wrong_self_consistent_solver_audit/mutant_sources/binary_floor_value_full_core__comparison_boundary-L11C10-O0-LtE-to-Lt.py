def trace(input_data):
    sess = TraceSession('记录候选二分查找', input_data, pseudocode=['维护闭区间 [left, right]', '计算 mid = (left+right)//2', '若 nums[mid] <= target，记录 ans 并右移 left', '否则左移 right'])
    nums = input_data['nums']
    target = input_data['target']
    arr = sess.array('nums', nums)
    left = sess.pointer('left', on=arr, idx=0)
    right = sess.pointer('right', on=arr, idx=len(arr) - 1)
    ans_idx = sess.scalar('ans', -1)
    while left.idx < right.idx:
        mid = (left.idx + right.idx) // 2
        with sess.step(f'mid={mid} nums[mid]={nums[mid]}'):
            arr.highlight(mid, role='current')
            if nums[mid] <= target:
                ans_idx.set(mid, reason=f'候选更新为 {mid}')
                left.move(mid + 1, reason=f'nums[{mid}] <= target，向右搜索')
            else:
                right.move(mid - 1, reason=f'nums[{mid}] > target，向左搜索')
    answer = nums[ans_idx.value] if ans_idx.value != -1 else -1
    sess.result(answer)
    trace = sess.to_trace()
    for event in trace['events']:
        op = event.get('op')
        targets = [t.get('id', '') for t in event.get('targets', [])]
        if op == 'create' and 'nums' in targets:
            event['code_line'] = 2
        elif op == 'create' and 'left' in targets:
            event['code_line'] = 5
        elif op == 'create' and 'right' in targets:
            event['code_line'] = 5
        elif op == 'create' and 'ans' in targets:
            event['code_line'] = 4
        elif op == 'move' and 'left' in targets:
            event['code_line'] = 10
        elif op == 'move' and 'right' in targets:
            event['code_line'] = 12
        elif op == 'set' and 'ans' in targets:
            event['code_line'] = 9
        elif event.get('role') == 'answer':
            event['code_line'] = 13
        elif 'highlight' in targets:
            event['code_line'] = 7
        else:
            event['code_line'] = 6
    return trace
