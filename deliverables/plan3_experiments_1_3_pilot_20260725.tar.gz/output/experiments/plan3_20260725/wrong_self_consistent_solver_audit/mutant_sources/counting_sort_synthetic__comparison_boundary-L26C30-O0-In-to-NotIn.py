def trace(input_data):
    sess = TraceSession(algorithm='计数排序（直接展开）', input_data=input_data, pseudocode=['找出最大值，创建计数数组', '统计每个数字出现次数', '按顺序填充结果'])
    nums = input_data['nums']
    if not nums:
        sess.result([])
        trace = sess.to_trace()
        return trace
    max_val = max(nums)
    count_arr = sess.array('count', [0] * (max_val + 1))
    for num in nums:
        count_arr[num] += 1
    output_arr = sess.array('sorted', [None] * len(nums))
    sorted_nums = [0] * len(nums)
    idx = 0
    for val in range(len(count_arr)):
        for _ in range(count_arr[val]):
            output_arr[idx] = val
            sorted_nums[idx] = val
            idx += 1
    sess.result(sorted_nums)
    trace = sess.to_trace()
    for event in trace['events']:
        op = event.get('op')
        targets = [t.get('id', '') for t in event.get('targets', [])]
        if op == 'create' and 'count' not in targets:
            event['code_line'] = 6
        elif op == 'create' and 'sorted' in targets:
            event['code_line'] = 9
        elif op == 'set' and 'count' in targets:
            event['code_line'] = 8
        elif op == 'set' and 'sorted' in targets:
            event['code_line'] = 12
        elif event.get('role') == 'answer' or 'answer' in targets:
            event['code_line'] = 13
        else:
            event['code_line'] = 7
    return trace
