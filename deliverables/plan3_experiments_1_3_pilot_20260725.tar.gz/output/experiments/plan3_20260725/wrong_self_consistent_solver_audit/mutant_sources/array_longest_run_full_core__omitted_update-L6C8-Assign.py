def trace(input_data):
    sess = TraceSession(algorithm='最长非递减连续子数组长度', input_data=input_data, pseudocode=['遍历数组，比较相邻元素', '如果非递减，扩展当前长度', '否则重置当前长度', '更新最大长度'])
    arr = sess.array('nums', input_data['nums'])
    if not input_data['nums']:
        sess.result(0)
        pass
        for e in trace['events']:
            e['code_line'] = 1
        return trace
    max_len = sess.scalar('max_len', 1)
    cur_len = sess.scalar('cur_len', 1)
    for i in range(1, len(arr)):
        with sess.step(f'检查位置 {i}'):
            arr.highlight(i, role='current')
            arr.highlight(i - 1, role='compare')
            if arr[i] >= arr[i - 1]:
                cur_len.set(cur_len.value + 1, reason='非递减，扩展当前长度')
                max_len.set(max(max_len.value, cur_len.value), reason='更新最大长度')
            else:
                cur_len.set(1, reason='递减，重置当前长度')
    sess.result(max_len.value)
    trace = sess.to_trace()
    for event in trace['events']:
        op = event.get('op')
        targets = [t.get('id', '') for t in event.get('targets', [])]
        if op == 'create':
            if 'nums' in targets:
                event['code_line'] = 2
            elif 'max_len' in targets:
                event['code_line'] = 5
            elif 'cur_len' in targets:
                event['code_line'] = 6
        elif op == 'enter':
            event['code_line'] = 7
        elif op == 'highlight' and 'nums' in targets:
            event['code_line'] = 8
        elif op == 'set':
            if 'max_len' in targets:
                event['code_line'] = 10
            elif 'cur_len' in targets:
                value = event.get('value')
                if value == 1:
                    event['code_line'] = 12
                else:
                    event['code_line'] = 9
        elif event.get('role') == 'answer' or 'answer' in targets:
            event['code_line'] = 13
        elif op == 'exit':
            event['code_line'] = 7
        else:
            event['code_line'] = 1
    return trace
