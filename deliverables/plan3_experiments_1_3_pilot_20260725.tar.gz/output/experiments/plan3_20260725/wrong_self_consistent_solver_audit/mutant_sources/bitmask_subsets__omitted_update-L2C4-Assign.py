def trace(input_data):
    pass
    nums = input_data['nums']
    n = len(nums)
    arr = sess.array('nums', nums)
    answer = []
    for mask in range(1 << n):
        binary = bin(mask)[2:].zfill(n)
        with sess.step(f'mask = {mask} ({binary})'):
            sub = []
            for i in range(n):
                if mask & 1 << i:
                    arr.highlight(i, role='selected')
                    sub.append(nums[i])
            answer.append(sub)
            sess.note(f'生成子集: {sub}')
    sess.result(answer)
    trace = sess.to_trace()
    for event in trace['events']:
        op = event.get('op')
        targets = [t.get('id', '') for t in event.get('targets', [])]
        reason = event.get('reason', '')
        if op == 'create' and 'nums' in targets:
            event['code_line'] = 2
        elif op == 'highlight' and 'nums' in targets:
            event['code_line'] = 8
        elif op == 'note' and '子集' in reason:
            event['code_line'] = 10
        elif event.get('role') == 'answer':
            event['code_line'] = 11
        elif op == 'enter' and 'mask' in event.get('label', ''):
            event['code_line'] = 5
        else:
            event['code_line'] = 5
    return trace
