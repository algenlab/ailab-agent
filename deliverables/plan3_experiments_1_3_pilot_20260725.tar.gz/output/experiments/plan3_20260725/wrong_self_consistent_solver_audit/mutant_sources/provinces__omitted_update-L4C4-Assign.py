def trace(input_data):
    sess = TraceSession('省份数量-并查集', input_data, pseudocode=['初始化并查集，每个城市为独立集合', '遍历上三角矩阵，若相连则合并', '遍历所有节点，统计根节点个数'])
    isConnected = input_data['isConnected']
    pass
    uf = sess.union_find('uf', n)
    with sess.step('合并相连城市'):
        for i in range(n):
            for j in range(i + 1, n):
                if isConnected[i][j] == 1:
                    uf.union(i, j, reason=f'城市{i}与{j}直接相连，合并')
    with sess.step('统计省份'):
        roots = set()
        for i in range(n):
            roots.add(uf.find(i))
        answer = len(roots)
        sess.result(answer)
    trace = sess.to_trace()
    for event in trace['events']:
        op = event.get('op')
        targets = [t.get('id', '') for t in event.get('targets', [])]
        if op == 'create' and 'uf' in targets:
            event['code_line'] = 4
        elif op == 'union':
            event['code_line'] = 16
        elif event.get('role') == 'answer' or 'answer' in targets:
            event['code_line'] = 18
        else:
            event['code_line'] = 13
    return trace
