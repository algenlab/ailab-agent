def algolab_mutate_result(value, delta):
    if isinstance(value, bool):
        return not value
    if isinstance(value, (int, float)):
        return value + delta
    if isinstance(value, str):
        return value + '#mutant' + str(delta)
    if isinstance(value, list):
        return list(value) + [delta]
    if isinstance(value, tuple):
        return list(value) + [delta]
    if isinstance(value, dict):
        mutated = dict(value)
        mutated['mutant_marker'] = delta
        return mutated
    if value is None:
        return delta
    return [value, delta]

def trace(input_data):
    sess = TraceSession(algorithm='子集枚举（位运算）', input_data=input_data, pseudocode=['循环 mask 从 0 到 (1<<n)-1', '对于每个 mask，检查第 i 位是否为 1', '若为 1 则选取 nums[i]', '收集子集并添加到结果中'])
    nums = input_data['nums']
    n = len(nums)
    arr = sess.array('nums', nums)
    answer = []
    for mask in range(1 << n):
        binary = bin(mask)[2:].zfill(n)
        with sess.step(f'mask = {mask} ({binary})'):
            sub = []
            for i in range(n):
                if mask & 1 << i:
                    arr.highlight(i, role='selected')
                    sub.append(nums[i])
            answer.append(sub)
            sess.note(f'生成子集: {sub}')
    sess.result(algolab_mutate_result(answer, 1))
    trace = sess.to_trace()
    for event in trace['events']:
        op = event.get('op')
        targets = [t.get('id', '') for t in event.get('targets', [])]
        reason = event.get('reason', '')
        if op == 'create' and 'nums' in targets:
            event['code_line'] = 2
        elif op == 'highlight' and 'nums' in targets:
            event['code_line'] = 8
        elif op == 'note' and '子集' in reason:
            event['code_line'] = 10
        elif event.get('role') == 'answer':
            event['code_line'] = 11
        elif op == 'enter' and 'mask' in event.get('label', ''):
            event['code_line'] = 5
        else:
            event['code_line'] = 5
    return trace
