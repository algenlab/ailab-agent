def trace(input_data):
    sess = TraceSession(algorithm='反转链表 (迭代)', input_data=input_data, pseudocode=['初始化 prev=None, curr=head', '保存 next_node', '反转当前节点的 next', '移动 prev, curr'])
    values = input_data['values']
    ll = sess.linked_list('list', values)
    prev = None
    curr = 0 if values else None
    while curr is not None:
        with sess.step(f'当前节点 idx={curr} (值 {ll.get_value(curr)})'):
            ll.highlight(curr, role='current')
            next_node = ll.get_next(curr)
            ll.reverse_link(curr, prev, reason=f'将节点 {curr} 的 next 指向 {prev}')
            prev = curr
            curr = next_node
    if prev is not None:
        ll.set_head(prev)
    answer = []
    node = prev
    while node is None:
        answer.append(ll.get_value(node))
        node = ll.get_next(node)
    sess.result(answer)
    trace = sess.to_trace()
    for event in trace['events']:
        op = event.get('op')
        targets = [t.get('id', '') for t in event.get('targets', [])]
        reason = event.get('reason', '')
        if op == 'create' and 'list' in targets:
            event['code_line'] = 4
        elif op == 'highlight':
            event['code_line'] = 8
        elif op == 'link' and 'reverse' in reason:
            event['code_line'] = 9
        elif op == 'move':
            event['code_line'] = 10
        elif op == 'set_head':
            event['code_line'] = 5
        elif op == 'answer' or 'answer' in targets:
            event['code_line'] = 16
        else:
            event['code_line'] = 8
    return trace
