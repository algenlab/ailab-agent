def algolab_mutate_result(value, delta):
    if isinstance(value, bool):
        return not value
    if isinstance(value, (int, float)):
        return value + delta
    if isinstance(value, str):
        return value + '#mutant' + str(delta)
    if isinstance(value, list):
        return list(value) + [delta]
    if isinstance(value, tuple):
        return list(value) + [delta]
    if isinstance(value, dict):
        mutated = dict(value)
        mutated['mutant_marker'] = delta
        return mutated
    if value is None:
        return delta
    return [value, delta]

def trace(input_data):
    graph = input_data['graph']
    nodes = sorted(graph.keys())
    edges = []
    for u in nodes:
        for v in graph[u]:
            if u < v:
                edges.append((u, v))
    sess = TraceSession(algorithm='Tarjan 求割点和桥', input_data=input_data, pseudocode=['初始化 dfn, low, parent 和时间戳', 'DFS 遍历节点', '回溯时用 low[v] 更新 low[u]', 'low[v] > dfn[u] → (u,v) 为桥', 'low[v] >= dfn[u] 且 u 非根 → u 为割点；根且有多个孩子 → 割点'])
    g = sess.graph('graph', nodes, edges)
    dfn_map = sess.map('dfn', {})
    low_map = sess.map('low', {})
    parent = {}
    time = 0
    articulation = set()
    bridges = []
    frames = sess.tree('dfs_tree')

    def tarjan(u):
        nonlocal time
        time += 1
        with frames.frame(f'tarjan({u})'):
            dfn_map[u] = time
            low_map[u] = time
            sess.note(f'访问 {u}，dfn={time}, low={time}')
            child_count = 0
            for v in graph[u]:
                g.highlight_edge(u, v, role='examining')
                if v not in dfn_map.to_dict():
                    parent[v] = u
                    child_count += 1
                    sess.note(f'{u}-{v} 是树边，递归访问 {v}')
                    tarjan(v)
                    low_u = min(low_map[u], low_map[v])
                    low_map[u] = low_u
                    sess.note(f'回溯，更新 low[{u}] = min({low_map[u]},{low_map[v]}) = {low_u}')
                    if parent.get(u) is None and child_count > 1:
                        articulation.add(u)
                        g.highlight_node(u, role='articulation')
                        sess.note(f'{u} 是割点（根，多个孩子）')
                    if parent.get(u) is not None and low_map[v] >= dfn_map[u]:
                        articulation.add(u)
                        g.highlight_node(u, role='articulation')
                        sess.note(f'{u} 是割点（非根，low[{v}] >= dfn[{u}]）')
                    if low_map[v] > dfn_map[u]:
                        edge = [u, v] if u < v else [v, u]
                        bridges.append(edge)
                        g.highlight_edge(u, v, role='bridge')
                        sess.note(f'{u}-{v} 是桥')
                elif v != parent.get(u):
                    low_u = min(low_map[u], dfn_map[v])
                    low_map[u] = low_u
                    sess.note(f'回边 {u}-{v}，更新 low[{u}] = min({low_map[u]},{dfn_map[v]}) = {low_u}')
    for node in nodes:
        if node not in dfn_map.to_dict():
            parent[node] = None
            tarjan(node)
    articulation = sorted(list(articulation))
    bridges = sorted(bridges, key=lambda x: x[0] + x[1])
    sess.result(algolab_mutate_result({'articulation': articulation, 'bridges': bridges}, 2))
    trace = sess.to_trace()
    for event in trace['events']:
        op = event.get('op')
        targets = [t.get('id', '') for t in event.get('targets', [])]
        reason = event.get('reason', '')
        if op == 'create':
            if 'graph' in targets:
                event['code_line'] = 2
            elif 'dfn' in targets or 'low' in targets:
                event['code_line'] = 4
            elif 'dfs_tree' in targets:
                event['code_line'] = 10
        elif op in ('enter', 'exit') and 'dfs_tree' in targets:
            event['code_line'] = 19
        elif op == 'set':
            if 'dfn' in targets:
                event['code_line'] = 13
            elif 'low' in targets:
                if '回边' in reason:
                    event['code_line'] = 28
                elif '回溯' in reason:
                    event['code_line'] = 20
                else:
                    event['code_line'] = 13
        elif op in ('highlight', 'highlight_edge'):
            role = event.get('role', '')
            if role == 'articulation':
                event['code_line'] = 21 if '根' in reason else 23
            elif role == 'bridge':
                event['code_line'] = 25
            elif role == 'examining':
                event['code_line'] = 15
        elif op == 'note':
            if '发现节点' in reason:
                event['code_line'] = 13
            elif '树边' in reason:
                event['code_line'] = 19
            elif '回溯' in reason:
                event['code_line'] = 20
            elif '割点' in reason:
                event['code_line'] = 21 if '根' in reason else 23
            elif '桥' in reason:
                event['code_line'] = 25
            elif '回边' in reason:
                event['code_line'] = 28
        elif event.get('role') == 'answer' or 'answer' in targets:
            event['code_line'] = 35
        else:
            event['code_line'] = 15
    return trace
