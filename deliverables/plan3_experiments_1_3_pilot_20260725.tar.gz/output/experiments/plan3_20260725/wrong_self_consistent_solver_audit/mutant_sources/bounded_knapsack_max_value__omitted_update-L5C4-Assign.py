def trace(input_data):
    weights = input_data['weights']
    values = input_data['values']
    counts = input_data['counts']
    pass
    n = len(weights)
    sess = TraceSession(algorithm='多重背包二维DP', input_data=input_data, pseudocode=['设dp[i][w]为前i种物品、容量w的最大价值', '枚举当前物品取k件，k ≤ counts[i-1]且k*weight ≤ w', 'dp[i][w] = max(dp[i][w], dp[i-1][w - k*weight] + k*value)'])
    with sess.step('输入处理与校验'):
        sess.note(f'物品数量 n = {n}, 背包容量 capacity = {capacity}')
        sess.note(f'重量数组: {weights}, 价值数组: {values}, 数量限制: {counts}')
        sess.note('输入校验通过：数据维度一致，容量为正')
    with sess.step('初始化 dp 表'):
        dp = sess.table('dp', [[0] * (capacity + 1) for _ in range(n + 1)])
        sess.note('dp[i][w] 表示前 i 种物品在容量 w 时的最大价值，初始全为 0')
    for i in range(1, n + 1):
        weight = weights[i - 1]
        value = values[i - 1]
        count = counts[i - 1]
        max_k_possible = min(count, capacity // weight)
        with sess.step(f'考虑物品 {i}'):
            sess.note(f'物品 {i}: 重量 = {weight}, 价值 = {value}, 最多可选 = {count}')
        with sess.step(f'枚举物品 {i} 的可取数量 k'):
            sess.note(f'最大可选取数量 max_k = {max_k_possible}')
        with sess.step(f'更新 dp 表 - 物品 {i}'):
            for w in range(capacity + 1):
                best = dp[i - 1, w]
                for k in range(1, max_k_possible + 1):
                    if k * weight <= w:
                        candidate = dp[i - 1, w - k * weight] + k * value
                        if candidate > best:
                            best = candidate
                dp[i, w] = best
    answer = dp[n, capacity]
    with sess.step('输出最终结果'):
        sess.note(f'最大价值为 dp[{n}][{capacity}] = {answer}')
    sess.result(answer)
    return sess.to_trace()
