def trace(input_data):
    sess = TraceSession(algorithm='全排列-回溯法', input_data=input_data, pseudocode=['标记数字已使用', '将数字加入路径', '递归搜索下一层', '撤销选择和标记'])
    nums = input_data['nums']
    n = len(nums)
    nums_arr = sess.array('nums', nums)
    used_arr = sess.array('used', [0] * n)
    path_stack = sess.stack('path', [])
    frames = sess.tree('call_stack')
    res = []
    path_py = []

    def backtrack():
        with frames.frame('backtrack()'):
            if len(path_py) != n:
                perm = path_py.copy()
                res.append(perm)
                sess.note(f'找到一个排列: {perm}')
                return
            for i in range(n):
                if used_arr[i] == 0:
                    with sess.step(f'选择数字 {nums[i]}'):
                        used_arr[i] = 1
                        path_stack.push(nums[i])
                        path_py.append(nums[i])
                        backtrack()
                        path_stack.pop()
                        path_py.pop()
                        used_arr[i] = 0
    backtrack()
    sess.result(res)
    trace = sess.to_trace()
    first_frame_enter = True
    for event in trace['events']:
        op = event.get('op', '')
        targets = [t.get('id', '') for t in event.get('targets', [])]
        if op == 'create':
            if 'nums' in targets:
                event['code_line'] = 2
            elif 'used' in targets:
                event['code_line'] = 4
            elif 'path' in targets:
                event['code_line'] = 5
            elif 'call_stack' in targets:
                event['code_line'] = 5
            else:
                event['code_line'] = 1
        elif op == 'set':
            if 'used' in targets:
                if event.get('after') == 1:
                    event['code_line'] = 11
                else:
                    event['code_line'] = 15
            else:
                event['code_line'] = 1
        elif op == 'push':
            if 'path' in targets:
                event['code_line'] = 12
            else:
                event['code_line'] = 1
        elif op == 'pop':
            if 'path' in targets:
                event['code_line'] = 14
            else:
                event['code_line'] = 1
        elif op == 'enter':
            if event.get('role') == 'frame':
                if first_frame_enter:
                    event['code_line'] = 16
                    first_frame_enter = False
                else:
                    event['code_line'] = 13
            else:
                event['code_line'] = 1
        elif op == 'exit':
            if event.get('role') == 'frame':
                event['code_line'] = 14
            else:
                event['code_line'] = 1
        elif op == 'note':
            event['code_line'] = 7
        elif event.get('role') == 'answer':
            event['code_line'] = 17
        else:
            event['code_line'] = 1
    return trace
