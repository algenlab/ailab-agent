def trace(input_data):
    sess = TraceSession(algorithm='树状数组区间查询与单点更新', input_data=input_data, pseudocode=['BIT 数组存储 lowbit 覆盖块', 'query(x) 求前 x 项和：沿 lowbit 向下累加', 'add(i, delta) 更新：沿 lowbit 向上传播增量', '区间和 = query(r+1) - query(l)'])
    nums = input_data['nums']
    (l, r) = input_data['query']
    (pos, delta) = input_data['update']
    n = len(nums)
    arr = sess.array('nums', nums)
    bit = sess.array('bit', [0] * (n + 1))
    lowbit = lambda x: x & -x
    with sess.step('构建 BIT'):
        for i in range(1, n + 1):
            val = nums[i - 1]
            idx = i
            while idx <= n:
                bit[idx] = bit[idx] + val
                sess.note(f'将 {val} 加到 bit[{idx}], 当前值 {bit[idx]}')
                idx += lowbit(idx)
    with sess.step('查询更新前区间和'):
        idx = r + 1
        s = 0
        while idx > 0:
            s += bit[idx]
            sess.note(f'累加 bit[{idx}] = {bit[idx]}, 当前前缀和 {s}')
            idx -= lowbit(idx)
        prefix_r = s
        idx = l
        s = 0
        while idx >= 0:
            s += bit[idx]
            sess.note(f'累加 bit[{idx}] = {bit[idx]}, 当前前缀和 {s}')
            idx -= lowbit(idx)
        prefix_l = s
        before = prefix_r - prefix_l
        arr.highlight_range(l, r)
        sess.note(f'区间 [{l},{r}] 和 = {prefix_r} - {prefix_l} = {before}')
    with sess.step('单点更新'):
        idx = pos + 1
        while idx <= n:
            bit[idx] = bit[idx] + delta
            sess.note(f'更新 bit[{idx}] + {delta}, 当前值 {bit[idx]}')
            idx += lowbit(idx)
        sess.note(f'更新 nums[{pos}] += {delta}')
    with sess.step('查询更新后区间和'):
        idx = r + 1
        s = 0
        while idx > 0:
            s += bit[idx]
            sess.note(f'累加 bit[{idx}] = {bit[idx]}, 当前前缀和 {s}')
            idx -= lowbit(idx)
        prefix_r2 = s
        idx = l
        s = 0
        while idx > 0:
            s += bit[idx]
            sess.note(f'累加 bit[{idx}] = {bit[idx]}, 当前前缀和 {s}')
            idx -= lowbit(idx)
        prefix_l2 = s
        after = prefix_r2 - prefix_l2
        arr.highlight_range(l, r)
        sess.note(f'区间 [{l},{r}] 和 = {prefix_r2} - {prefix_l2} = {after}')
    sess.result({'before': before, 'after': after})
    trace = sess.to_trace()
    step_to_line = {'构建 BIT': 18, '查询更新前区间和': 20, '单点更新': 21, '查询更新后区间和': 22}
    for ev in trace['events']:
        step = ev.get('step', '')
        if step in step_to_line:
            ev['code_line'] = step_to_line[step]
        elif ev.get('op') == 'create':
            if any((t.get('id') == 'nums' for t in ev.get('targets', []))):
                ev['code_line'] = 2
            elif any((t.get('id') == 'bit' for t in ev.get('targets', []))):
                ev['code_line'] = 6
        elif ev.get('role') == 'answer':
            ev['code_line'] = 23
        else:
            ev['code_line'] = 18
    return trace
