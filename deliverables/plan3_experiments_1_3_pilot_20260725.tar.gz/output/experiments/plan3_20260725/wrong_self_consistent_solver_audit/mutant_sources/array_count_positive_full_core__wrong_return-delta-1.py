def algolab_mutate_result(value, delta):
    if isinstance(value, bool):
        return not value
    if isinstance(value, (int, float)):
        return value + delta
    if isinstance(value, str):
        return value + '#mutant' + str(delta)
    if isinstance(value, list):
        return list(value) + [delta]
    if isinstance(value, tuple):
        return list(value) + [delta]
    if isinstance(value, dict):
        mutated = dict(value)
        mutated['mutant_marker'] = delta
        return mutated
    if value is None:
        return delta
    return [value, delta]

def trace(input_data):
    sess = TraceSession(algorithm='统计正数个数', input_data=input_data, pseudocode=['遍历每个元素', '检查是否大于0', '若大于0则计数加一'])
    nums = sess.array('nums', input_data['nums'])
    count = sess.scalar('count', 0)
    with sess.step('遍历数组'):
        for i in range(len(nums)):
            x = nums[i]
            nums.highlight(i)
            if x > 0:
                count.set(count.value + 1, reason=f'{x} > 0, 计数加1')
            else:
                sess.note(f'{x} 不大于0')
    answer = count.value
    sess.result(algolab_mutate_result(answer, 1))
    return sess.to_trace()
