def trace(input_data):
    sess = TraceSession(algorithm='最长非递减连续子数组', input_data=input_data, pseudocode=['初始化 cur_len=1, max_len=1', '遍历 i=1..n-1', '如果 nums[i] >= nums[i-1] 则 cur_len+=1 并更新 max_len', '否则 cur_len=1'])
    pass
    arr = sess.array('nums', nums)
    if not nums:
        sess.result(0)
        return sess.to_trace()
    max_len = sess.scalar('max_len', value=1)
    cur_len = sess.scalar('cur_len', value=1)
    for i in range(1, len(nums)):
        with sess.step(f'检查 nums[{i}]={nums[i]} 是否 >= nums[{i - 1}]={nums[i - 1]}'):
            arr.highlight(i - 1, role='prev')
            arr.highlight(i, role='current')
            if nums[i] >= nums[i - 1]:
                cur_len.set(cur_len.value + 1, reason=f'延续非递减，cur_len={cur_len.value}')
                if cur_len.value > max_len.value:
                    max_len.set(cur_len.value, reason='更新最大长度')
            else:
                cur_len.set(1, reason='断开，重置cur_len=1')
            arr.unhighlight(i - 1)
            arr.unhighlight(i)
    sess.result(max_len.value)
    trace = sess.to_trace()
    for event in trace['events']:
        op = event.get('op')
        targets = [t.get('id', '') for t in event.get('targets', [])]
        if op == 'create' and 'nums' in targets:
            event['code_line'] = 2
        elif op == 'create' and ('max_len' in targets or 'cur_len' in targets):
            event['code_line'] = 4
        elif op == 'set' and 'cur_len' in targets:
            if event.get('reason', '').startswith('延续'):
                event['code_line'] = 7
            elif event.get('reason', '').startswith('断开'):
                event['code_line'] = 9
        elif op == 'set' and 'max_len' in targets:
            event['code_line'] = 8
        elif op in ('highlight', 'unhighlight'):
            event['code_line'] = 6
        elif op in ('step_enter', 'step_exit'):
            event['code_line'] = 5
        elif event.get('role') == 'answer':
            event['code_line'] = 10
        else:
            event['code_line'] = 1
    return trace
