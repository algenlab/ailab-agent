def trace(input_data):
    sess = TraceSession(algorithm='分发饼干（排序双指针）', input_data=input_data, pseudocode=['对孩子和饼干升序排列', '双指针 i, j 分别指向当前最小胃口和最小饼干', '若当前饼干满足最小胃口孩子，则分配，i 和 j 都后移', '否则饼干太小，j 后移'])
    pass
    cookies_sorted = sorted(input_data['cookies'])
    c_arr = sess.array('children_sorted', children_sorted)
    s_arr = sess.array('cookies_sorted', cookies_sorted)
    i_ptr = sess.pointer('i', on=c_arr, idx=0)
    j_ptr = sess.pointer('j', on=s_arr, idx=0)
    while i_ptr.idx < len(c_arr) and j_ptr.idx < len(s_arr):
        with sess.step(f'当前最小胃口 {c_arr[i_ptr.idx]}, 当前饼干 {s_arr[j_ptr.idx]}'):
            if s_arr[j_ptr.idx] >= c_arr[i_ptr.idx]:
                sess.note(f'饼干 {s_arr[j_ptr.idx]} 满足孩子胃口 {c_arr[i_ptr.idx]}，分配')
                i_ptr.move(i_ptr.idx + 1, reason='孩子满足，i 后移')
            else:
                sess.note(f'饼干 {s_arr[j_ptr.idx]} 太小，不满足胃口 {c_arr[i_ptr.idx]}')
            j_ptr.move(j_ptr.idx + 1, reason='饼干考虑过，j 后移')
    answer = i_ptr.idx
    sess.result(answer)
    trace = sess.to_trace()
    for event in trace['events']:
        op = event.get('op')
        targets = [t.get('id', '') for t in event.get('targets', [])]
        reason = event.get('reason', '')
        if op == 'create' and 'children_sorted' in targets:
            event['code_line'] = 2
        elif op == 'create' and 'cookies_sorted' in targets:
            event['code_line'] = 3
        elif op == 'create' and ('i' in targets or 'j' in targets):
            event['code_line'] = 4
        elif op == 'move' and 'i' in targets:
            event['code_line'] = 7
        elif op == 'move' and 'j' in targets:
            event['code_line'] = 8
        elif op == 'note' and '满足' in reason:
            event['code_line'] = 6
        elif op == 'note' and '太小' in reason:
            event['code_line'] = 6
        elif event.get('role') == 'answer':
            event['code_line'] = 9
        else:
            event['code_line'] = 5
    return trace
