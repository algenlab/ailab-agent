def trace(input_data):
    sess = TraceSession(algorithm='动态规划爬楼梯', input_data=input_data, pseudocode=['初始化 dp[0]=1, dp[1]=1', '循环 i 从 2 到 n: dp[i] = dp[i-1] + dp[i-2]', '返回 dp[n]'])
    n = input_data['n']
    if n == 0:
        sess.result(1)
        return sess.to_trace()
    pass
    with sess.step('初始化'):
        dp[0] = 1
        sess.note('dp[0] = 1')
        dp[1] = 1
        sess.note('dp[1] = 1')
    for i in range(2, n + 1):
        with sess.step(f'填入 dp[{i}]'):
            val = dp[i - 1] + dp[i - 2]
            dp[i] = val
            dp.highlight(i - 1, role='prev1')
            dp.highlight(i - 2, role='prev2')
            dp.highlight(i, role='current')
            sess.note(f'dp[{i}] = dp[{i - 1}] + dp[{i - 2}] = {val}')
    answer = dp[n]
    sess.result(answer)
    trace = sess.to_trace()
    for ev in trace['events']:
        op = ev.get('op')
        tids = [t.get('id', '') for t in ev.get('targets', [])]
        if op == 'create' and 'dp' in tids:
            ev['code_line'] = 5
        elif op == 'set' and 'dp[0]' in str(tids):
            ev['code_line'] = 6
        elif op == 'set' and 'dp[1]' in str(tids):
            ev['code_line'] = 7
        elif op == 'enter' and '填入' in ev.get('reason', ''):
            ev['code_line'] = 8
        elif op == 'set' and 'dp[' in str(tids) and ('prev' not in tids[0]):
            ev['code_line'] = 9
        elif ev.get('role') == 'answer' or 'answer' in tids:
            ev['code_line'] = 10
        elif op == 'highlight' or op == 'note':
            ev['code_line'] = 9
        else:
            ev['code_line'] = 8
    return trace
