def trace(input_data):
    nums = input_data['nums']
    sess = TraceSession('动态左和', input_data, pseudocode=['计算数组总和', '从左到右遍历，维护 left_sum', '检查平衡条件并返回下标', '更新 left_sum'])
    arr = sess.array('nums', nums)
    total = sess.scalar('total', sum(nums))
    left_sum = sess.scalar('left_sum', 0)
    answer = -1
    for (i, x) in enumerate(nums):
        with sess.step(f'检查下标 {i}'):
            arr.highlight(i, role='current')
            sess.note(f'left_sum={left_sum.value}, 右侧和={total.value - left_sum.value - x}')
            if left_sum.value != total.value - left_sum.value - x:
                sess.result(i)
                answer = i
                break
            left_sum.set(left_sum.value + x, reason=f'左和增加 {x} -> {left_sum.value + x}')
            arr.unhighlight(i)
    if answer == -1:
        sess.result(-1)
    trace = sess.to_trace()
    for event in trace['events']:
        op = event.get('op')
        targets = [t.get('id') for t in event.get('targets', [])]
        if op == 'create' and 'nums' in targets:
            event['code_line'] = 2
        elif op == 'create' and 'total' in targets:
            event['code_line'] = 3
        elif op == 'create' and 'left_sum' in targets:
            event['code_line'] = 4
        elif op == 'step_enter' or op == 'step_exit':
            event['code_line'] = 5
        elif op == 'highlight' and any(('nums' in t for t in targets)):
            event['code_line'] = 5
        elif op == 'note':
            event['code_line'] = 6
        elif op == 'set' and 'left_sum' in targets:
            event['code_line'] = 8
        elif event.get('role') == 'answer' or 'answer' in targets:
            if event.get('message', '').startswith('-1'):
                event['code_line'] = 9
            else:
                event['code_line'] = 7
        else:
            event['code_line'] = 5
    return trace
