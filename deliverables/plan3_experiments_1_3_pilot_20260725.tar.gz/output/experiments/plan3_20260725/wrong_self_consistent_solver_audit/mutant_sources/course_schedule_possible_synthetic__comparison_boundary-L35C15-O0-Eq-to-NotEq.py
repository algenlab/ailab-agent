def trace(input_data):
    sess = TraceSession(algorithm='Course Schedule - BFS', input_data=input_data, pseudocode=['计算所有课程的入度', '入度为0的课程入队', '出队并删除出边，更新邻居入度', '若所有课程都被取出，则无环'])
    n = input_data['n']
    prereq = input_data['prerequisites']
    nodes = list(range(n))
    edges = [(v, u) for (u, v) in prereq]
    g = sess.graph('graph', nodes, edges, directed=True)
    indegree = sess.array('indegree', [0] * n)
    adj = [[] for _ in range(n)]
    with sess.step('计算入度'):
        for (u, v) in prereq:
            adj[v].append(u)
            indegree[u] = indegree[u] + 1
    q = sess.queue('queue')
    count = 0
    with sess.step('初始入队'):
        for i in range(n):
            if indegree[i] == 0:
                q.push(i)
    while not q.empty():
        with sess.step('处理出队节点'):
            node = q.pop()
            count += 1
            g.highlight_node(node, role='current')
            with sess.step('更新邻居入度'):
                for neighbor in adj[node]:
                    indegree[neighbor] = indegree[neighbor] - 1
                    if indegree[neighbor] != 0:
                        q.push(neighbor)
    answer = count == n
    sess.result(answer)
    return sess.to_trace()
