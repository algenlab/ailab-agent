def trace(input_data):
    sess = TraceSession(algorithm='扫描法', input_data=input_data, pseudocode=['初始化 max_len, cur_len', '遍历相邻元素比较', '更新当前长度与全局最大'])
    nums = input_data['nums']
    if not nums:
        sess.result(0)
        return sess.to_trace()
    pass
    max_len = sess.scalar('max_len', 1)
    cur_len = sess.scalar('cur_len', 1)
    p = sess.pointer('i', on=arr, idx=0)
    i = 1
    while i < len(nums):
        p.move(i, reason=f'检查位置 {i}')
        if arr[i] >= arr[i - 1]:
            with sess.step('非递减，扩展'):
                cur_len.set(cur_len.value + 1, reason='扩展当前长度')
        else:
            with sess.step('递减，重置'):
                cur_len.set(1, reason='重置当前长度')
        if cur_len.value > max_len.value:
            max_len.set(cur_len.value, reason='更新最大长度')
        i += 1
    sess.result(max_len.value)
    trace = sess.to_trace()
    for ev in trace['events']:
        op = ev.get('op')
        targets = [t.get('id', '') for t in ev.get('targets', [])]
        reason = ev.get('reason', '')
        if op == 'create' and 'nums' in targets:
            ev['code_line'] = 2
        elif op == 'create' and 'max_len' in targets:
            ev['code_line'] = 4
        elif op == 'create' and 'cur_len' in targets:
            ev['code_line'] = 5
        elif op == 'create' and 'i' in targets:
            ev['code_line'] = 7
        elif op == 'move' and 'i' in targets:
            ev['code_line'] = 8
        elif op == 'enter' and '非递减' in reason:
            ev['code_line'] = 9
        elif op == 'set' and 'cur_len' in targets and ('扩展' in reason):
            ev['code_line'] = 10
        elif op == 'enter' and '递减' in reason:
            ev['code_line'] = 11
        elif op == 'set' and 'cur_len' in targets and ('重置' in reason):
            ev['code_line'] = 12
        elif op == 'exit':
            ev['code_line'] = ev.get('code_line', 9)
        elif op == 'set' and 'max_len' in targets:
            ev['code_line'] = 14
        elif op == 'result' or ev.get('role') == 'answer':
            ev['code_line'] = 15
        else:
            ev['code_line'] = 8
    return trace
