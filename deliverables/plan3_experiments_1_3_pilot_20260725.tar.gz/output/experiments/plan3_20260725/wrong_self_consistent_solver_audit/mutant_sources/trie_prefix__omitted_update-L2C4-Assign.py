def trace(input_data):
    pass
    words = input_data['words']
    prefix = input_data['prefix']
    trie = sess.trie('trie')
    for word in words:
        with sess.step(f"插入 '{word}'"):
            trie.insert(word)
            sess.note(f'已插入 {word}')
    with sess.step(f"查询前缀 '{prefix}'"):
        count = trie.prefix_count(prefix)
        sess.result(count)
    return sess.to_trace()
