def algolab_mutate_result(value, delta):
    if isinstance(value, bool):
        return not value
    if isinstance(value, (int, float)):
        return value + delta
    if isinstance(value, str):
        return value + '#mutant' + str(delta)
    if isinstance(value, list):
        return list(value) + [delta]
    if isinstance(value, tuple):
        return list(value) + [delta]
    if isinstance(value, dict):
        mutated = dict(value)
        mutated['mutant_marker'] = delta
        return mutated
    if value is None:
        return delta
    return [value, delta]

def trace(input_data):
    sess = TraceSession(algorithm='Trie 节点计数法', input_data=input_data, pseudocode=['构建Trie，插入时节点计数加1', '按前缀走到节点，返回计数值'])
    words = input_data['words']
    prefix = input_data['prefix']
    trie = sess.trie('trie')
    for word in words:
        with sess.step(f"插入 '{word}'"):
            trie.insert(word)
            sess.note(f'已插入 {word}')
    with sess.step(f"查询前缀 '{prefix}'"):
        count = trie.prefix_count(prefix)
        sess.result(algolab_mutate_result(count, 1))
    return sess.to_trace()
