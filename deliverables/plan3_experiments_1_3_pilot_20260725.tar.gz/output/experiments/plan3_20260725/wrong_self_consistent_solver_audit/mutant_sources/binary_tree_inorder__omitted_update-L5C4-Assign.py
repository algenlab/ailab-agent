def trace(input_data):
    sess = TraceSession('递归中序遍历', input_data, pseudocode=['递归左子树', '访问当前节点', '递归右子树'])
    pass
    node_ids = [n['id'] for n in tree_data['nodes']]
    edges = tree_data['edges']
    g = sess.graph('tree', node_ids, edges, directed=False)
    frames = sess.tree('call_stack')
    adj = {nid: [] for nid in node_ids}
    for (p, c) in edges:
        adj[p].append(c)
    parent_of = {}
    child_type = {}
    for p in adj:
        children = adj[p]
        for (i, c) in enumerate(children):
            parent_of[c] = p
            child_type[c] = 'left' if i == 0 else 'right'
    order = []

    def inorder(node):
        if node is None:
            return
        with frames.frame(f'inorder({node})'):
            left = adj[node][0] if len(adj[node]) > 0 else None
            right = adj[node][1] if len(adj[node]) > 1 else None
            inorder(left)
            g.highlight_node(node, role='visited')
            order.append(node)
            sess.note(f'访问节点 {node}')
            inorder(right)
    if node_ids:
        inorder(node_ids[0])
    sess.result(order)
    trace = sess.to_trace()
    for event in trace['events']:
        op = event.get('op')
        targets = [t.get('id', '') for t in event.get('targets', [])]
        if op == 'create' and 'tree' in targets:
            event['code_line'] = 2
        elif op == 'create' and 'call_stack' in targets:
            event['code_line'] = 8
        elif op in ('enter', 'exit'):
            frame_name = targets[0] if targets else ''
            if frame_name.startswith('inorder(') and frame_name.endswith(')'):
                nid = frame_name[8:-1]
                if nid == node_ids[0]:
                    event['code_line'] = 18
                else:
                    parent = parent_of.get(nid)
                    if parent and child_type.get(nid) == 'left':
                        event['code_line'] = 13
                    else:
                        event['code_line'] = 15
        elif op == 'highlight' and any(('visited' in t.get('role', '') for t in event.get('targets', []))):
            event['code_line'] = 14
        elif op == 'note':
            event['code_line'] = 14
        elif 'answer' in event.get('role', '') or op == 'result':
            event['code_line'] = 19
    return trace
