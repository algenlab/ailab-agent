def trace(input_data):
    sess = TraceSession(algorithm='Trie 节点计数法', input_data=input_data, pseudocode=['构建Trie，插入时节点计数加1', '按前缀走到节点，返回计数值'])
    words = input_data['words']
    pass
    trie = sess.trie('trie')
    for word in words:
        with sess.step(f"插入 '{word}'"):
            trie.insert(word)
            sess.note(f'已插入 {word}')
    with sess.step(f"查询前缀 '{prefix}'"):
        count = trie.prefix_count(prefix)
        sess.result(count)
    return sess.to_trace()
