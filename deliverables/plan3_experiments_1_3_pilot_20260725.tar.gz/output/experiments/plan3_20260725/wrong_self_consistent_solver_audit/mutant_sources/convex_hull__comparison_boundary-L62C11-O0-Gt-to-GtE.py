def trace(input_data):
    sess = TraceSession(algorithm='Andrew单调链凸包算法', input_data=input_data, pseudocode=['将点按x坐标排序', '构建下凸壳：从左到右遍历，维护栈', '构建上凸壳：从右到左遍历，维护栈', '合并下凸壳和上凸壳（去掉重合端点）'])
    pts_raw = input_data['points']
    sorted_pts = sorted(pts_raw)
    pts = sess.points('points', sorted_pts)
    point_to_idx = {tuple(p): i for (i, p) in enumerate(sorted_pts)}
    with sess.step('排序点集（按x坐标）'):
        sess.note(f'点已排序：{sorted_pts}')
    lower_stack = sess.stack('lower_hull')
    lower_data = []
    with sess.step('构建下凸壳（从左到右）'):
        for (i, p) in enumerate(sorted_pts):
            pts.highlight(i, role='current')
            while len(lower_data) > 2:
                o = lower_data[-2]
                a = lower_data[-1]
                b = tuple(p)
                cross_val = (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
                if cross_val <= 0:
                    popped = lower_stack.pop(reason=f'叉积≤0，弹出 {a}')
                    lower_data.pop()
                    pop_idx = point_to_idx[popped]
                    pts.highlight(pop_idx, role='excluded')
                else:
                    break
            lower_stack.push(tuple(p), reason=f'加入点 {p}')
            lower_data.append(tuple(p))
            pts.highlight(i, role='added')
    upper_stack = sess.stack('upper_hull')
    upper_data = []
    with sess.step('构建上凸壳（从右到左）'):
        for i in range(len(sorted_pts) - 1, -1, -1):
            p = sorted_pts[i]
            pts.highlight(i, role='current')
            while len(upper_data) >= 2:
                o = upper_data[-2]
                a = upper_data[-1]
                b = tuple(p)
                cross_val = (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
                if cross_val <= 0:
                    popped = upper_stack.pop(reason=f'叉积≤0，弹出 {a}')
                    upper_data.pop()
                    pop_idx = point_to_idx[popped]
                    pts.highlight(pop_idx, role='excluded')
                else:
                    break
            upper_stack.push(tuple(p), reason=f'加入点 {p}')
            upper_data.append(tuple(p))
            pts.highlight(i, role='added')
    with sess.step('合并上下凸壳'):
        lower_hull = lower_data[:-1]
        upper_hull = upper_data[:-1]
        hull = lower_hull + upper_hull
        for pt in hull:
            idx = point_to_idx[pt]
            pts.highlight(idx, role='convex')
        n = len(hull)
        if n > 0:
            for k in range(n):
                i1 = point_to_idx[hull[k]]
                i2 = point_to_idx[hull[(k + 1) % n]]
                pts.add_segment(i1, i2)
        sess.note(f'凸包顶点：{hull}')
    sess.result(hull)
    trace = sess.to_trace()
    for event in trace['events']:
        op = event.get('op')
        targets = [t.get('id', '') for t in event.get('targets', [])]
        reason = event.get('reason', '')
        if op == 'create' and 'points' in targets:
            event['code_line'] = 5
        elif op == 'create' and 'lower_hull' in targets:
            event['code_line'] = 8
        elif op == 'create' and 'upper_hull' in targets:
            event['code_line'] = 13
        elif op == 'push' and 'lower_hull' in targets:
            event['code_line'] = 12
        elif op == 'pop' and 'lower_hull' in targets:
            event['code_line'] = 11
        elif op == 'push' and 'upper_hull' in targets:
            event['code_line'] = 17
        elif op == 'pop' and 'upper_hull' in targets:
            event['code_line'] = 16
        elif op == 'highlight' and 'current' in reason:
            event['code_line'] = 9
        elif op == 'highlight' and 'added' in reason:
            event['code_line'] = 12
        elif op == 'highlight' and 'excluded' in reason:
            event['code_line'] = 11
        elif op == 'highlight' and 'convex' in reason:
            event['code_line'] = 18
        elif op == 'add_segment':
            event['code_line'] = 18
        elif op == 'note':
            event['code_line'] = 18
        elif op == 'answer' or 'answer' in event.get('role', ''):
            event['code_line'] = 18
        else:
            event['code_line'] = 9
    return trace
