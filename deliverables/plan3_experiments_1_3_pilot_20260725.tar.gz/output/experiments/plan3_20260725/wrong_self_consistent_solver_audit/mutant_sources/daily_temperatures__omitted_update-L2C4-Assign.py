def trace(input_data):
    pass
    temps = input_data['temperatures']
    n = len(temps)
    arr = sess.array('temperatures', temps)
    res = sess.array('answer', [0] * n)
    stack = sess.stack('stack')
    i_ptr = sess.pointer('i', on=arr, idx=0)
    for i in range(n):
        i_ptr.move(i, reason=f'处理第{i}天')
        arr.highlight(i, role='current')
        with sess.step(f'第{i}天温度 {temps[i]}°C'):
            while not stack.empty() and arr[stack.peek()] < temps[i]:
                prev = stack.peek()
                arr.highlight(prev, role='comparing')
                sess.note(f'栈顶第{prev}天温度较低，弹出并记录')
                res[prev] = i - prev
                stack.pop()
                arr.unhighlight(prev)
            stack.push(i)
            sess.note(f'压入第{i}天，等待未来更高温度')
    sess.result(res.to_list())
    return sess.to_trace()
