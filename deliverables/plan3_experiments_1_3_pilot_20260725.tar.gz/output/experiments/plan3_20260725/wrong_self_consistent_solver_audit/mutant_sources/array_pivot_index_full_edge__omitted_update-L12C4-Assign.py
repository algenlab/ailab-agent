def trace(input_data):
    sess = TraceSession(algorithm='寻找中心下标（左右累加）', input_data=input_data, pseudocode=['计算数组总和 total', '遍历数组，维护左侧和 left_sum', '若 left_sum * 2 == total - nums[i]，返回 i', '否则 left_sum 累加当前元素，继续遍历'])
    pass
    arr = sess.array('nums', nums)
    total = sum(nums)
    total_scalar = sess.scalar('total', total)
    left_sum_scalar = sess.scalar('left_sum', 0)
    i_ptr = sess.pointer('i', on=arr, idx=0)
    answer = -1
    while i_ptr.idx < len(arr):
        num = arr[i_ptr.idx]
        with sess.step(f'检查下标 {i_ptr.idx}'):
            arr.highlight(i_ptr.idx, role='current')
            if left_sum_scalar.value * 2 == total - num:
                sess.note(f'找到中心下标 {i_ptr.idx}')
                answer = i_ptr.idx
                break
            else:
                left_sum_scalar.set(left_sum_scalar.value + num, reason=f'累加 {num} 到左侧和')
                i_ptr.move(i_ptr.idx + 1, reason='指针右移一位')
    sess.result(answer)
    trace = sess.to_trace()
    for event in trace['events']:
        op = event.get('op')
        targets = [t.get('id', '') for t in event.get('targets', [])]
        if op == 'create' and 'nums' in targets:
            event['code_line'] = 2
        elif op == 'create' and 'total' in targets:
            event['code_line'] = 3
        elif op == 'create' and 'left_sum' in targets:
            event['code_line'] = 4
        elif op == 'create' and 'i' in targets:
            event['code_line'] = 5
        elif op == 'move' and 'i' in targets:
            event['code_line'] = 9
        elif event.get('role') == 'answer' or 'answer' in targets:
            if answer == -1:
                event['code_line'] = 10
            else:
                event['code_line'] = 7
        elif op == 'highlight' and 'nums' in targets:
            event['code_line'] = 6
        elif op == 'set' and 'left_sum' in targets:
            event['code_line'] = 9
        elif op == 'note':
            event['code_line'] = 7 if answer != -1 else 6
        else:
            event['code_line'] = 6
    return trace
