def trace(input_data):
    pass
    nums = input_data['nums']
    k = input_data['k']
    arr = sess.array('nums', nums)
    h = sess.heap('heap', [])
    with sess.step('建堆'):
        for (i, val) in enumerate(nums):
            arr.highlight(i, role='current')
            h.push(val, reason=f'将 {val} 推入堆')
            arr.unhighlight(i)
    answer = []
    with sess.step('弹出最小k个数'):
        for _ in range(k):
            if h.empty():
                break
            val = h.pop()
            answer.append(val)
            sess.note(f'弹出 {val}')
    sess.result(answer)
    trace = sess.to_trace()
    for event in trace['events']:
        op = event.get('op')
        if op == 'create' and event['targets'][0]['id'] == 'nums':
            event['code_line'] = 2
        elif op == 'push':
            event['code_line'] = 5
        elif op == 'pop':
            event['code_line'] = 6
        elif event.get('role') == 'note' and event.get('reason', '').startswith('弹出'):
            event['code_line'] = 6
        elif event.get('role') == 'answer' or 'answer' in str(event.get('targets')):
            event['code_line'] = 7
        else:
            event['code_line'] = 5
    return trace
