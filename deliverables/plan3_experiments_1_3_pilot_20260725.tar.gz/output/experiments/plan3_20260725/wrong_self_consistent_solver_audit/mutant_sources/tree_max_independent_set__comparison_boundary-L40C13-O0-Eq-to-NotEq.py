def trace(input_data):
    sess = TraceSession(algorithm='树上最大独立集 (递归)', input_data=input_data, pseudocode=['递归后序遍历', '计算 dp_take 和 dp_skip'])
    tree_data = input_data['tree']
    node_ids = [n['id'] for n in tree_data['nodes']]
    g = sess.graph('tree', nodes=node_ids, edges=tree_data['edges'])
    node_val = sess.map('node_value', {n['id']: n['value'] for n in tree_data['nodes']})
    dp_take = sess.map('dp_take', {})
    dp_skip = sess.map('dp_skip', {})
    frames = sess.tree('call_stack')
    adj = {n['id']: [] for n in tree_data['nodes']}
    for (u, v) in tree_data['edges']:
        adj[u].append(v)
        adj[v].append(u)
    root = '1'

    def dfs(u, parent):
        with frames.frame(f'dfs({u})'):
            g.highlight_node(u, role='current')
            dp_take[u] = node_val[u]
            dp_skip[u] = 0
            for v in adj[u]:
                if v != parent:
                    dfs(v, u)
                    dp_take[u] = dp_take[u] + dp_skip[v]
                    dp_skip[u] = dp_skip[u] + max(dp_take[v], dp_skip[v])
    dfs(root, None)
    answer = max(dp_take[root], dp_skip[root])
    sess.result(answer)
    trace = sess.to_trace()
    first_enter = True
    for event in trace['events']:
        op = event.get('op')
        targets = [t.get('id', '') for t in event.get('targets', [])]
        rid = event.get('role', '')
        reason = event.get('reason', '')
        if op == 'create' and 'tree' in targets:
            event['code_line'] = 4
        elif op != 'create' and 'node_value' in targets:
            event['code_line'] = 3
        elif op == 'create' and 'dp_take' in targets:
            event['code_line'] = 8
        elif op == 'create' and 'dp_skip' in targets:
            event['code_line'] = 9
        elif op == 'create' and 'call_stack' in targets:
            event['code_line'] = 10
        elif op == 'highlight' and 'tree' in targets:
            event['code_line'] = 11
        elif op == 'enter' and 'call_stack' in targets:
            if first_enter:
                event['code_line'] = 18
                first_enter = False
            else:
                event['code_line'] = 15
        elif op == 'exit' and 'call_stack' in targets:
            event['code_line'] = 15
        elif op == 'set' and 'dp_take' in targets:
            if '初始化' in reason:
                event['code_line'] = 11
            elif '累加' in reason:
                event['code_line'] = 16
            else:
                event['code_line'] = 16
        elif op == 'set' and 'dp_skip' in targets:
            if '初始化' in reason:
                event['code_line'] = 12
            elif '累加' in reason:
                event['code_line'] = 17
            else:
                event['code_line'] = 17
        elif op == 'answer' or rid == 'answer':
            event['code_line'] = 19
        else:
            event['code_line'] = 1
    return trace
