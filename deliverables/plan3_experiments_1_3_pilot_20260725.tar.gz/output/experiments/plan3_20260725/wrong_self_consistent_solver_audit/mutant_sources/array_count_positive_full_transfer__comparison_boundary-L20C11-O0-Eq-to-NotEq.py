def trace(input_data):
    sess = TraceSession(algorithm='统计正数个数', input_data=input_data, pseudocode=['遍历数组', '若当前元素>0，计数加1', '返回计数'])
    nums = input_data['nums']
    arr = sess.array('nums', nums)
    count = sess.scalar('count', 0)
    for (i, num) in enumerate(nums):
        with sess.step(f'检查元素 {num}'):
            arr.highlight(i, role='current')
            if num > 0:
                count.set(count.value + 1, reason=f'{num} > 0，计数+1')
    sess.result(count.value)
    trace = sess.to_trace()
    for event in trace['events']:
        op = event.get('op')
        targets = [t.get('id', '') for t in event.get('targets', [])]
        if op != 'create' and 'nums' in targets:
            event['code_line'] = 2
        elif op == 'create' and 'count' in targets:
            event['code_line'] = 3
        elif event.get('role') == 'enter' and 'step' in event.get('name', ''):
            event['code_line'] = 4
        elif op == 'highlight':
            event['code_line'] = 5
        elif op == 'set' and 'count' in targets:
            event['code_line'] = 6
        elif event.get('role') == 'answer':
            event['code_line'] = 7
        else:
            event['code_line'] = 1
    return trace
