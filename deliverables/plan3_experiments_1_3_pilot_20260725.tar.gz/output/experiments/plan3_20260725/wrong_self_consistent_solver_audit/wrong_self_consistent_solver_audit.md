# Wrong-but-Self-Consistent Solver Audit

- Tasks: 30
- Families: 23
- Mutation attempts: 235
- Applicable mutants: 60
- Not applicable: 174

| Metric | Passed | Rate | Wilson 95% CI |
|---|---:|---:|---:|
| internal_consistency | 60/60 | 1.0000 | [0.9398, 1.0000] |
| oracle_mismatch | 60/60 | 1.0000 | [0.9398, 1.0000] |
| oracle_gate_detection | 60/60 | 1.0000 | [0.9398, 1.0000] |
| release_rejection | 60/60 | 1.0000 | [0.9398, 1.0000] |

Blocking defects: 0
