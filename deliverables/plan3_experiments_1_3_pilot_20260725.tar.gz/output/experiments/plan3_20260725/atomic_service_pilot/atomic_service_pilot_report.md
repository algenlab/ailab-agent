# Atomic-Service 23-Family Pilot

| Metric | Atomic | Decoupled | Difference | 95% bootstrap CI | McNemar p |
|---|---:|---:|---:|---:|---:|
| final_generation_pass | 21/23 | 21/23 | 0.0000 | [-0.1304, 0.1304] | 1 |
| machine_ok | 20/23 | 21/23 | -0.0435 | [-0.1739, 0.0870] | 1 |
| execution_validation | 20/20 | 20/20 | 0.0000 | [0.0000, 0.0000] | 1 |
| execution_binding | 20/20 | 20/20 | 0.0000 | [0.0000, 0.0000] | 1 |
| prefix_replay | 20/20 | 20/20 | 0.0000 | [0.0000, 0.0000] | 1 |
| unlogged_mutation_free | 20/20 | 20/20 | 0.0000 | [0.0000, 0.0000] | 1 |
| state_event_mismatch_free | 20/20 | 20/20 | 0.0000 | [0.0000, 0.0000] | 1 |

| Condition | Generation pass | Tokens/task | Tokens/valid tutor | Model calls/task | Repair calls/task | API latency/task |
|---|---:|---:|---:|---:|---:|---:|
| atomic | 21/23 | 96699.7 | 111204.6 | 6.913 | 1.304 | 680.0s |
| decoupled | 21/23 | 101724.5 | 111412.6 | 7.217 | 1.783 | 693.7s |
