# Interaction Semantic Evaluation Report

- created_at: `2026-07-25T12:40:02`
- json: `output/experiments/plan3_20260725/atomic_service_pilot/machine_audits/atomic/shard_3/interaction_semantic_eval_report.json`

## Condition Summary

| Condition | Total | Machine OK | Visible Answer | Interaction | Correct FB | Wrong FB | Hint | Show Answer | Log | Mutation-free | Process | Interact Sem | Teaching | Visual |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| atomic_service | 5 | 5 | 5 | 5 | 5 | 5 | 5 | 5 | 5 | 5 | None | None | None | None |

## Case Records

| Case | Condition | Machine OK | Answer | Interaction | Correct FB | Wrong FB | Hint | Show | Log | Mutation-free |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| tree_max_independent_set | atomic_service | True | True | True | True | True | True | True | True | True |
| trie_prefix_expansion | atomic_service | True | True | True | True | True | True | True | True | True |
| hash_first_repeated_full_edge | atomic_service | True | True | True | True | True | True | True | True | True |
| greedy_assign_cookies_full_edge | atomic_service | True | True | True | True | True | True | True | True | True |
| dp_grid_paths_obstacles_full_transfer | atomic_service | True | True | True | True | True | True | True | True | True |
