# Interaction Semantic Evaluation Report

- created_at: `2026-07-25T12:40:03`
- json: `output/experiments/plan3_20260725/atomic_service_pilot/machine_audits/atomic/shard_2/interaction_semantic_eval_report.json`

## Condition Summary

| Condition | Total | Machine OK | Visible Answer | Interaction | Correct FB | Wrong FB | Hint | Show Answer | Log | Mutation-free | Process | Interact Sem | Teaching | Visual |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| atomic_service | 6 | 4 | 5 | 5 | 4 | 4 | 5 | 5 | 5 | 5 | None | None | None | None |

## Case Records

| Case | Condition | Machine OK | Answer | Interaction | Correct FB | Wrong FB | Hint | Show | Log | Mutation-free |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| graph_bipartite_coloring | atomic_service | True | True | True | True | True | True | True | True | True |
| reverse_linked_list | atomic_service | True | True | True | True | True | True | True | True | True |
| first_ge_binary_search_synthetic | atomic_service | True | True | True | True | True | True | True | True | True |
| bipartite_matching | atomic_service | False | True | True | False | False | True | True | True | True |
| heap_last_stone_full_edge | atomic_service | True | True | True | True | True | True | True | True | True |
| bst_insert_inorder_synthetic | atomic_service | False | False | False | False | False | False | False | False | False |
