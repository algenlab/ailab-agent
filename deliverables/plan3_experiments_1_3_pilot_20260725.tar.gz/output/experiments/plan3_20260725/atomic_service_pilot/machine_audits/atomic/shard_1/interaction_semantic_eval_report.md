# Interaction Semantic Evaluation Report

- created_at: `2026-07-25T12:40:02`
- json: `output/experiments/plan3_20260725/atomic_service_pilot/machine_audits/atomic/shard_1/interaction_semantic_eval_report.json`

## Condition Summary

| Condition | Total | Machine OK | Visible Answer | Interaction | Correct FB | Wrong FB | Hint | Show Answer | Log | Mutation-free | Process | Interact Sem | Teaching | Visual |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| atomic_service | 6 | 5 | 5 | 5 | 5 | 5 | 5 | 5 | 5 | 5 | None | None | None | None |

## Case Records

| Case | Condition | Machine OK | Answer | Interaction | Correct FB | Wrong FB | Hint | Show | Log | Mutation-free |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| trie_prefix_match_string | atomic_service | True | True | True | True | True | True | True | True | True |
| gcd_euclid | atomic_service | True | True | True | True | True | True | True | True | True |
| permutations_expansion | atomic_service | True | True | True | True | True | True | True | True | True |
| min_cost_climbing_synthetic | atomic_service | True | True | True | True | True | True | True | True | True |
| bellman_ford_shortest_path | atomic_service | False | False | False | False | False | False | False | False | False |
| stack_remove_adjacent_duplicates_full_edge | atomic_service | True | True | True | True | True | True | True | True | True |
