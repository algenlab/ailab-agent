# Interaction Semantic Evaluation Report

- created_at: `2026-07-25T12:40:07`
- json: `output/experiments/plan3_20260725/atomic_service_pilot/machine_audits/atomic/shard_0/interaction_semantic_eval_report.json`

## Condition Summary

| Condition | Total | Machine OK | Visible Answer | Interaction | Correct FB | Wrong FB | Hint | Show Answer | Log | Mutation-free | Process | Interact Sem | Teaching | Visual |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| atomic_service | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | None | None | None | None |

## Case Records

| Case | Condition | Machine OK | Answer | Interaction | Correct FB | Wrong FB | Hint | Show | Log | Mutation-free |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| provinces | atomic_service | True | True | True | True | True | True | True | True | True |
| segment_tree_range_sum | atomic_service | True | True | True | True | True | True | True | True | True |
| move_zeroes_stable_synthetic | atomic_service | True | True | True | True | True | True | True | True | True |
| convex_hull_expansion | atomic_service | True | True | True | True | True | True | True | True | True |
| sorting_inversion_count_full_core | atomic_service | True | True | True | True | True | True | True | True | True |
| knapsack_01_subset_sum | atomic_service | True | True | True | True | True | True | True | True | True |
