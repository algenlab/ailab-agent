# Interaction Semantic Evaluation Report

- created_at: `2026-07-25T13:01:26`
- json: `output/experiments/plan3_20260725/atomic_service_pilot/machine_audits/decoupled/shard_1/interaction_semantic_eval_report.json`

## Condition Summary

| Condition | Total | Machine OK | Visible Answer | Interaction | Correct FB | Wrong FB | Hint | Show Answer | Log | Mutation-free | Process | Interact Sem | Teaching | Visual |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| decoupled_service | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | None | None | None | None |

## Case Records

| Case | Condition | Machine OK | Answer | Interaction | Correct FB | Wrong FB | Hint | Show | Log | Mutation-free |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| provinces | decoupled_service | True | True | True | True | True | True | True | True | True |
| tree_max_independent_set | decoupled_service | True | True | True | True | True | True | True | True | True |
| min_cost_climbing_synthetic | decoupled_service | True | True | True | True | True | True | True | True | True |
| first_ge_binary_search_synthetic | decoupled_service | True | True | True | True | True | True | True | True | True |
| greedy_assign_cookies_full_edge | decoupled_service | True | True | True | True | True | True | True | True | True |
| convex_hull_expansion | decoupled_service | True | True | True | True | True | True | True | True | True |
