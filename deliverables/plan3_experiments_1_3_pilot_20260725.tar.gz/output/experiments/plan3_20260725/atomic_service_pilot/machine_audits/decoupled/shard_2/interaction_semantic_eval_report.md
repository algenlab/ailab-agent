# Interaction Semantic Evaluation Report

- created_at: `2026-07-25T13:01:28`
- json: `output/experiments/plan3_20260725/atomic_service_pilot/machine_audits/decoupled/shard_2/interaction_semantic_eval_report.json`

## Condition Summary

| Condition | Total | Machine OK | Visible Answer | Interaction | Correct FB | Wrong FB | Hint | Show Answer | Log | Mutation-free | Process | Interact Sem | Teaching | Visual |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| decoupled_service | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | None | None | None | None |

## Case Records

| Case | Condition | Machine OK | Answer | Interaction | Correct FB | Wrong FB | Hint | Show | Log | Mutation-free |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| trie_prefix_match_string | decoupled_service | True | True | True | True | True | True | True | True | True |
| trie_prefix_expansion | decoupled_service | True | True | True | True | True | True | True | True | True |
| segment_tree_range_sum | decoupled_service | True | True | True | True | True | True | True | True | True |
| stack_remove_adjacent_duplicates_full_edge | decoupled_service | True | True | True | True | True | True | True | True | True |
| heap_last_stone_full_edge | decoupled_service | True | True | True | True | True | True | True | True | True |
| sorting_inversion_count_full_core | decoupled_service | True | True | True | True | True | True | True | True | True |
