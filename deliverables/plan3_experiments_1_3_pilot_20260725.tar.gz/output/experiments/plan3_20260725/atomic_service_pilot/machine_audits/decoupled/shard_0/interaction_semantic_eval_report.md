# Interaction Semantic Evaluation Report

- created_at: `2026-07-25T13:01:22`
- json: `output/experiments/plan3_20260725/atomic_service_pilot/machine_audits/decoupled/shard_0/interaction_semantic_eval_report.json`

## Condition Summary

| Condition | Total | Machine OK | Visible Answer | Interaction | Correct FB | Wrong FB | Hint | Show Answer | Log | Mutation-free | Process | Interact Sem | Teaching | Visual |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| decoupled_service | 6 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | None | None | None | None |

## Case Records

| Case | Condition | Machine OK | Answer | Interaction | Correct FB | Wrong FB | Hint | Show | Log | Mutation-free |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| graph_bipartite_coloring | decoupled_service | True | True | True | True | True | True | True | True | True |
| gcd_euclid | decoupled_service | True | True | True | True | True | True | True | True | True |
| knapsack_01_subset_sum | decoupled_service | False | False | False | False | False | False | False | False | False |
| hash_first_repeated_full_edge | decoupled_service | True | True | True | True | True | True | True | True | True |
| bellman_ford_shortest_path | decoupled_service | False | False | False | False | False | False | False | False | False |
| dp_grid_paths_obstacles_full_transfer | decoupled_service | True | True | True | True | True | True | True | True | True |
