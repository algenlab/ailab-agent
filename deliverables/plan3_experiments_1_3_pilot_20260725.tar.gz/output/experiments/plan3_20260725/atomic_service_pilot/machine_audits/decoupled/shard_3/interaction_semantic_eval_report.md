# Interaction Semantic Evaluation Report

- created_at: `2026-07-25T13:01:26`
- json: `output/experiments/plan3_20260725/atomic_service_pilot/machine_audits/decoupled/shard_3/interaction_semantic_eval_report.json`

## Condition Summary

| Condition | Total | Machine OK | Visible Answer | Interaction | Correct FB | Wrong FB | Hint | Show Answer | Log | Mutation-free | Process | Interact Sem | Teaching | Visual |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| decoupled_service | 5 | 5 | 5 | 5 | 5 | 5 | 5 | 5 | 5 | 5 | None | None | None | None |

## Case Records

| Case | Condition | Machine OK | Answer | Interaction | Correct FB | Wrong FB | Hint | Show | Log | Mutation-free |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| reverse_linked_list | decoupled_service | True | True | True | True | True | True | True | True | True |
| permutations_expansion | decoupled_service | True | True | True | True | True | True | True | True | True |
| bipartite_matching | decoupled_service | True | True | True | True | True | True | True | True | True |
| bst_insert_inorder_synthetic | decoupled_service | True | True | True | True | True | True | True | True | True |
| move_zeroes_stable_synthetic | decoupled_service | True | True | True | True | True | True | True | True | True |
