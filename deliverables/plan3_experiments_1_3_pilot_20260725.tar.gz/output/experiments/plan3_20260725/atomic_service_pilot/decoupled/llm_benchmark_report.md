# LLM Benchmark Report

- 缓存：未使用
- 模型：DeepSeek-V4-Pro
- 总数：23
- 通过：21
- 失败：2
- 通过率：91.30%
- 平均耗时：699.245s/case
- LLM calls：166
- Token usage：2339664
- 候选策略：max_candidates=2, repairs_per_candidate=2
- 候选命中：first_try=5, repair=10, regen=6, failed=2
- 平均候选数：1.347826
- 平均 LLM calls/题：7.217391
- Case set：deterministic
- 严格 warning：开启
- 浏览器检查：关闭

| Case | Sample | Family | Case Set | Style | Status | Failure | Duration | Last Phase | Artifact |
|---|---:|---|---|---|---|---|---:|---|---|
| graph_bipartite_coloring | 0 | BFS/DFS 基础图 | deterministic | seen_style | PASS |  | 417.2s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/decoupled/llm_graph_bipartite_coloring_0.html |
| provinces | 0 | 并查集 | deterministic | seen_style | PASS |  | 473.037s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/decoupled/llm_provinces_0.html |
| trie_prefix_match_string | 0 | 字符串高级算法 | deterministic | seen_style | PASS |  | 481.841s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/decoupled/llm_trie_prefix_match_string_0.html |
| reverse_linked_list | 0 | 链表与缓存 | deterministic | seen_style | PASS |  | 543.446s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/decoupled/llm_reverse_linked_list_0.html |
| gcd_euclid | 0 | 数学与位运算 | deterministic | seen_style | PASS |  | 363.535s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/decoupled/llm_gcd_euclid_0.html |
| tree_max_independent_set | 0 | 树形 DP | deterministic | seen_style | PASS |  | 993.371s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/decoupled/llm_tree_max_independent_set_0.html |
| trie_prefix_expansion | 0 | Trie | deterministic | seen_style | PASS |  | 542.964s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/decoupled/llm_trie_prefix_expansion_0.html |
| permutations_expansion | 0 | 回溯 / 递归 | deterministic | seen_style | PASS |  | 519.966s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/decoupled/llm_permutations_expansion_0.html |
| knapsack_01_subset_sum | 0 | DP 核心扩展 | deterministic | seen_style | FAIL | generation | 1156.773s | candidate_1_materialize_round_2:ok |  |
| min_cost_climbing_synthetic | 0 | 一维 DP | deterministic | seen_style | PASS |  | 245.409s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/decoupled/llm_min_cost_climbing_synthetic_0.html |
| segment_tree_range_sum | 0 | 区间结构 | deterministic | seen_style | PASS |  | 1413.104s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/decoupled/llm_segment_tree_range_sum_0.html |
| bipartite_matching | 0 | 图高级 | deterministic | seen_style | PASS |  | 979.36s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/decoupled/llm_bipartite_matching_0.html |
| hash_first_repeated_full_edge | 0 | 哈希表 / map | deterministic | seen_style | PASS |  | 213.261s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/decoupled/llm_hash_first_repeated_full_edge_0.html |
| first_ge_binary_search_synthetic | 0 | 二分 | deterministic | seen_style | PASS |  | 531.45s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/decoupled/llm_first_ge_binary_search_synthetic_0.html |
| stack_remove_adjacent_duplicates_full_edge | 0 | 栈 / 队列 / 单调栈 | deterministic | seen_style | PASS |  | 180.048s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/decoupled/llm_stack_remove_adjacent_duplicates_full_edge_0.html |
| bst_insert_inorder_synthetic | 0 | 树 / BST / LCA | deterministic | seen_style | PASS |  | 496.497s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/decoupled/llm_bst_insert_inorder_synthetic_0.html |
| bellman_ford_shortest_path | 0 | 最短路 / MST | deterministic | seen_style | FAIL | visual_warning | 1696.609s | candidate_1_materialize_round_2:ok |  |
| greedy_assign_cookies_full_edge | 0 | 贪心 | deterministic | seen_style | PASS |  | 194.285s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/decoupled/llm_greedy_assign_cookies_full_edge_0.html |
| heap_last_stone_full_edge | 0 | 堆 / TopK / Huffman | deterministic | seen_style | PASS |  | 251.619s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/decoupled/llm_heap_last_stone_full_edge_0.html |
| move_zeroes_stable_synthetic | 0 | 数组指针 / 窗口 / 前缀 | deterministic | seen_style | PASS |  | 1035.21s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/decoupled/llm_move_zeroes_stable_synthetic_0.html |
| dp_grid_paths_obstacles_full_transfer | 0 | 二维 DP | deterministic | seen_style | PASS |  | 551.152s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/decoupled/llm_dp_grid_paths_obstacles_full_transfer_0.html |
| convex_hull_expansion | 0 | 几何 / 扫描线 | deterministic | seen_style | PASS |  | 1723.297s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/decoupled/llm_convex_hull_expansion_0.html |
| sorting_inversion_count_full_core | 0 | 排序 | deterministic | seen_style | PASS |  | 1079.21s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/decoupled/llm_sorting_inversion_count_full_core_0.html |

## Phase Timings

| Phase | Count | Avg | Max |
|---|---:|---:|---:|
| candidate_0_generate | 23 | 102.332s | 185.604s |
| candidate_0_materialize_round_0 | 23 | 83.166s | 285.865s |
| candidate_0_materialize_round_1 | 18 | 118.251s | 336.341s |
| candidate_0_materialize_round_2 | 13 | 174.23s | 401.312s |
| candidate_0_repair_round_0 | 18 | 66.758s | 109.249s |
| candidate_0_repair_round_1 | 13 | 73.644s | 147.789s |
| candidate_1_generate | 8 | 108.004s | 167.201s |
| candidate_1_materialize_round_0 | 8 | 130.999s | 226.815s |
| candidate_1_materialize_round_1 | 7 | 254.269s | 317.46s |
| candidate_1_materialize_round_2 | 3 | 233.301s | 334.198s |
| candidate_1_repair_round_0 | 7 | 88.952s | 157.825s |
| candidate_1_repair_round_1 | 3 | 82.82s | 106.704s |
| render | 21 | 0.03s | 0.111s |

## Family Summary

| Family | Total | Pass Rate | Repair Success | Failure Types | Case Sets | Styles |
|---|---:|---:|---:|---|---|---|
| 图高级 | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
| 数组指针 / 窗口 / 前缀 | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
| 回溯 / 递归 | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
| BFS/DFS 基础图 | 1 | 100.00% | N/A |  | deterministic:1 | seen_style:1 |
| 二分 | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
| 一维 DP | 1 | 100.00% | N/A |  | deterministic:1 | seen_style:1 |
| 二维 DP | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
| DP 核心扩展 | 1 | 0.00% | 0.00% | generation:1 | deterministic:1 | seen_style:1 |
| 几何 / 扫描线 | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
| 贪心 | 1 | 100.00% | N/A |  | deterministic:1 | seen_style:1 |
| 哈希表 / map | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
| 堆 / TopK / Huffman | 1 | 100.00% | N/A |  | deterministic:1 | seen_style:1 |
| 链表与缓存 | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
| 数学与位运算 | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
| 栈 / 队列 / 单调栈 | 1 | 100.00% | N/A |  | deterministic:1 | seen_style:1 |
| 区间结构 | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
| 最短路 / MST | 1 | 0.00% | 0.00% | visual_warning:1 | deterministic:1 | seen_style:1 |
| 排序 | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
| 字符串高级算法 | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
| 树 / BST / LCA | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
| 树形 DP | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
| Trie | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
| 并查集 | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
