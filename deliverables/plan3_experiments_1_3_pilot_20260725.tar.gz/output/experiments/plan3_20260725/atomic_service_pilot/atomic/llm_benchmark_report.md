# LLM Benchmark Report

- 缓存：未使用
- 模型：DeepSeek-V4-Pro
- 总数：23
- 通过：21
- 失败：2
- 通过率：91.30%
- 平均耗时：686.946s/case
- LLM calls：159
- Token usage：2224093
- 候选策略：max_candidates=2, repairs_per_candidate=2
- 候选命中：first_try=11, repair=8, regen=2, failed=2
- 平均候选数：1.173913
- 平均 LLM calls/题：6.913043
- Case set：deterministic
- 严格 warning：开启
- 浏览器检查：关闭

| Case | Sample | Family | Case Set | Style | Status | Failure | Duration | Last Phase | Artifact |
|---|---:|---|---|---|---|---|---:|---|---|
| provinces | 0 | 并查集 | deterministic | seen_style | PASS |  | 225.715s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/atomic/llm_provinces_0.html |
| trie_prefix_match_string | 0 | 字符串高级算法 | deterministic | seen_style | PASS |  | 262.85s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/atomic/llm_trie_prefix_match_string_0.html |
| graph_bipartite_coloring | 0 | BFS/DFS 基础图 | deterministic | seen_style | PASS |  | 341.882s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/atomic/llm_graph_bipartite_coloring_0.html |
| tree_max_independent_set | 0 | 树形 DP | deterministic | seen_style | PASS |  | 435.955s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/atomic/llm_tree_max_independent_set_0.html |
| segment_tree_range_sum | 0 | 区间结构 | deterministic | seen_style | PASS |  | 523.573s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/atomic/llm_segment_tree_range_sum_0.html |
| gcd_euclid | 0 | 数学与位运算 | deterministic | seen_style | PASS |  | 344.635s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/atomic/llm_gcd_euclid_0.html |
| reverse_linked_list | 0 | 链表与缓存 | deterministic | seen_style | PASS |  | 645.543s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/atomic/llm_reverse_linked_list_0.html |
| trie_prefix_expansion | 0 | Trie | deterministic | seen_style | PASS |  | 318.994s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/atomic/llm_trie_prefix_expansion_0.html |
| move_zeroes_stable_synthetic | 0 | 数组指针 / 窗口 / 前缀 | deterministic | seen_style | PASS |  | 200.438s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/atomic/llm_move_zeroes_stable_synthetic_0.html |
| permutations_expansion | 0 | 回溯 / 递归 | deterministic | seen_style | PASS |  | 363.15s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/atomic/llm_permutations_expansion_0.html |
| first_ge_binary_search_synthetic | 0 | 二分 | deterministic | seen_style | PASS |  | 216.033s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/atomic/llm_first_ge_binary_search_synthetic_0.html |
| hash_first_repeated_full_edge | 0 | 哈希表 / map | deterministic | seen_style | PASS |  | 146.445s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/atomic/llm_hash_first_repeated_full_edge_0.html |
| convex_hull_expansion | 0 | 几何 / 扫描线 | deterministic | seen_style | PASS |  | 699.331s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/atomic/llm_convex_hull_expansion_0.html |
| min_cost_climbing_synthetic | 0 | 一维 DP | deterministic | seen_style | PASS |  | 884.154s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/atomic/llm_min_cost_climbing_synthetic_0.html |
| bipartite_matching | 0 | 图高级 | deterministic | seen_style | PASS |  | 1320.217s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/atomic/llm_bipartite_matching_0.html |
| greedy_assign_cookies_full_edge | 0 | 贪心 | deterministic | seen_style | PASS |  | 166.206s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/atomic/llm_greedy_assign_cookies_full_edge_0.html |
| sorting_inversion_count_full_core | 0 | 排序 | deterministic | seen_style | PASS |  | 853.579s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/atomic/llm_sorting_inversion_count_full_core_0.html |
| bellman_ford_shortest_path | 0 | 最短路 / MST | deterministic | seen_style | FAIL | visual_warning | 1857.69s | candidate_1_materialize_round_2:ok |  |
| heap_last_stone_full_edge | 0 | 堆 / TopK / Huffman | deterministic | seen_style | PASS |  | 315.204s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/atomic/llm_heap_last_stone_full_edge_0.html |
| dp_grid_paths_obstacles_full_transfer | 0 | 二维 DP | deterministic | seen_style | PASS |  | 675.221s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/atomic/llm_dp_grid_paths_obstacles_full_transfer_0.html |
| knapsack_01_subset_sum | 0 | DP 核心扩展 | deterministic | seen_style | PASS |  | 1919.425s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/atomic/llm_knapsack_01_subset_sum_0.html |
| stack_remove_adjacent_duplicates_full_edge | 0 | 栈 / 队列 / 单调栈 | deterministic | seen_style | PASS |  | 1261.519s | render:ok | /ssd1/liaokunpeng/paper/ailab-agent/output/experiments/plan3_20260725/atomic_service_pilot/atomic/llm_stack_remove_adjacent_duplicates_full_edge_0.html |
| bst_insert_inorder_synthetic | 0 | 树 / BST / LCA | deterministic | seen_style | FAIL | visual_warning | 1821.993s | candidate_1_materialize_round_2:ok |  |

## Phase Timings

| Phase | Count | Avg | Max |
|---|---:|---:|---:|
| candidate_0_generate | 23 | 113.191s | 268.995s |
| candidate_0_materialize_round_0 | 23 | 138.962s | 266.525s |
| candidate_0_materialize_round_1 | 12 | 210.36s | 290.471s |
| candidate_0_materialize_round_2 | 10 | 242.854s | 442.952s |
| candidate_0_repair_round_0 | 12 | 62.166s | 104.219s |
| candidate_0_repair_round_1 | 10 | 76.5s | 122.896s |
| candidate_1_generate | 4 | 134.79s | 217.564s |
| candidate_1_materialize_round_0 | 4 | 174.399s | 213.602s |
| candidate_1_materialize_round_1 | 4 | 273.067s | 592.377s |
| candidate_1_materialize_round_2 | 4 | 195.119s | 241.665s |
| candidate_1_repair_round_0 | 4 | 50.395s | 73.516s |
| candidate_1_repair_round_1 | 4 | 56.058s | 78.514s |
| render | 21 | 0.045s | 0.211s |

## Family Summary

| Family | Total | Pass Rate | Repair Success | Failure Types | Case Sets | Styles |
|---|---:|---:|---:|---|---|---|
| 图高级 | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
| 数组指针 / 窗口 / 前缀 | 1 | 100.00% | N/A |  | deterministic:1 | seen_style:1 |
| 回溯 / 递归 | 1 | 100.00% | N/A |  | deterministic:1 | seen_style:1 |
| BFS/DFS 基础图 | 1 | 100.00% | N/A |  | deterministic:1 | seen_style:1 |
| 二分 | 1 | 100.00% | N/A |  | deterministic:1 | seen_style:1 |
| 一维 DP | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
| 二维 DP | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
| DP 核心扩展 | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
| 几何 / 扫描线 | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
| 贪心 | 1 | 100.00% | N/A |  | deterministic:1 | seen_style:1 |
| 哈希表 / map | 1 | 100.00% | N/A |  | deterministic:1 | seen_style:1 |
| 堆 / TopK / Huffman | 1 | 100.00% | N/A |  | deterministic:1 | seen_style:1 |
| 链表与缓存 | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
| 数学与位运算 | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
| 栈 / 队列 / 单调栈 | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
| 区间结构 | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
| 最短路 / MST | 1 | 0.00% | 0.00% | visual_warning:1 | deterministic:1 | seen_style:1 |
| 排序 | 1 | 100.00% | 100.00% |  | deterministic:1 | seen_style:1 |
| 字符串高级算法 | 1 | 100.00% | N/A |  | deterministic:1 | seen_style:1 |
| 树 / BST / LCA | 1 | 0.00% | 0.00% | visual_warning:1 | deterministic:1 | seen_style:1 |
| 树形 DP | 1 | 100.00% | N/A |  | deterministic:1 | seen_style:1 |
| Trie | 1 | 100.00% | N/A |  | deterministic:1 | seen_style:1 |
| 并查集 | 1 | 100.00% | N/A |  | deterministic:1 | seen_style:1 |
