# Atomic-Service 23-Family Pilot

## 实验设置

- 样本规模：23 题，每个算法 family 1 题，共覆盖 23 个 family 和 23 个 subfamily。
- 条件：Atomic 与 Decoupled；Atomic 自动提交每次公开服务调用，Decoupled 通过显式 `record()` 确认提交，事件字段均由运行时生成并持有。
- 模型：DeepSeek-V4-Pro，temperature=0.2。
- 每题预算：2 个候选，每个候选最多 2 轮修复。
- 公共设置：严格 warning gate、教学增强、相同题序、相同 sample、相同机器审计。
- 主要指标：Machine OK。
- 次要指标：generation pass、执行 validation、same-execution binding、prefix replay、无漏记 mutation、无 state/event mismatch、模型调用、修复调用、tokens 与延迟。
- 二元指标：精确 McNemar 检验与 10,000 次 paired bootstrap；次要二元指标报告 Holm 校正后的 p 值。
- 所有差值方向：Atomic - Decoupled。

## 主要结果

| 指标 | Atomic | Decoupled | 差值 | 95% bootstrap CI | McNemar p |
|---|---:|---:|---:|---:|---:|
| Machine OK | 20/23 (86.96%) | 21/23 (91.30%) | -4.35 pp | [-17.39, 8.70] pp | 1.000 |
| Generation pass | 21/23 (91.30%) | 21/23 (91.30%) | 0.00 pp | [-13.04, 13.04] pp | 1.000 |

Machine OK 的不一致对为 Atomic-only 1 题、Decoupled-only 2 题。Generation pass 的不一致对为 Atomic-only 1 题、Decoupled-only 1 题；其 Holm 校正后 p=1.000。

## 执行机制指标

两种条件各有 21 题生成了可审计执行记录；两侧共同可观测的配对样本为 20 题。未生成执行记录的题目不计为机制失败。

| 指标 | Atomic 可观测通过 | Decoupled 可观测通过 | 配对 n | 配对差值 | 95% bootstrap CI | McNemar p | Holm p |
|---|---:|---:|---:|---:|---:|---:|---:|
| Execution validation | 21/21 | 21/21 | 20 | 0.00 pp | [0.00, 0.00] pp | 1.000 | 1.000 |
| Same-execution binding | 21/21 | 21/21 | 20 | 0.00 pp | [0.00, 0.00] pp | 1.000 | 1.000 |
| Prefix replay | 21/21 | 21/21 | 20 | 0.00 pp | [0.00, 0.00] pp | 1.000 | 1.000 |
| 无漏记 mutation | 21/21 | 21/21 | 20 | 0.00 pp | [0.00, 0.00] pp | 1.000 | 1.000 |
| 无 state/event mismatch | 21/21 | 21/21 | 20 | 0.00 pp | [0.00, 0.00] pp | 1.000 | 1.000 |

## 成本与延迟

| 指标 | Atomic | Decoupled | Atomic - Decoupled | 95% bootstrap CI |
|---|---:|---:|---:|---:|
| 模型调用/题 | 6.913 | 7.217 | -0.304 | [-2.522, 2.087] |
| 修复调用/题 | 1.304 | 1.783 | -0.478 | [-1.130, 0.217] |
| Tokens/题 | 96,699.7 | 101,724.5 | -5,024.8 | [-37,307.4, 28,639.8] |
| API latency/题 | 680.0 s | 693.7 s | -13.7 s | [-238.8, 219.7] s |
| 端到端耗时/题 | 686.9 s | 699.2 s | -12.3 s | [-238.1, 222.9] s |
| 总 tokens | 2,224,093 | 2,339,664 | -115,571 | - |
| Tokens/generation pass | 105,909.2 | 111,412.6 | -5,503.4 | - |
| Tokens/Machine OK | 111,204.7 | 111,412.6 | -208.0 | - |

## 失败分布

- Atomic generation failures：`bellman_ford_shortest_path`、`bst_insert_inorder_synthetic`。
- Decoupled generation failures：`knapsack_01_subset_sum`、`bellman_ford_shortest_path`。
- Atomic 额外 Machine OK failure：`bipartite_matching`，页面 JavaScript 语法错误。
- Decoupled 的 21 个生成成功产物全部通过 Machine OK。

## 结论

本 pilot 未观察到 Atomic 的可靠性优势。主要指标中 Decoupled 高 1/23，但置信区间较宽且精确 McNemar 检验不显著。Atomic 的平均调用、修复、tokens 和延迟均较低，但所有 paired bootstrap 区间均跨 0，不能确认成本优势。

基于本 pilot，约 30M tokens 的 Full-200 不启动。

## 限制

- 样本量仅 23，每个 family 只有 1 题，统计区间较宽。
- 单次随机生成不能分离模型采样波动与条件效应。
- Decoupled 条件评估的是显式提交确认，不评估模型手写事件字段的正确性。
- Generation 和 Machine OK 同时受严格教学门与页面运行错误影响，不只反映执行记录机制。
- Pilot 结果不能替代 Full-200，也不能证明两个条件等价。

## 实验产物

- 配对分析：`output/experiments/plan3_20260725/atomic_service_pilot/atomic_service_pilot_report.json`
- Markdown 汇总：`output/experiments/plan3_20260725/atomic_service_pilot/atomic_service_pilot_report.md`
- 指标 CSV：`output/experiments/plan3_20260725/atomic_service_pilot/atomic_service_pilot_report.csv`
- Pilot 清单：`output/experiments/plan3_20260725/atomic_service_pilot/pilot_manifest.json`
- Atomic 原始报告：`output/experiments/plan3_20260725/atomic_service_pilot/atomic/llm_benchmark_report.json`
- Decoupled 原始报告：`output/experiments/plan3_20260725/atomic_service_pilot/decoupled/llm_benchmark_report.json`
- Atomic 机器审计：`output/experiments/plan3_20260725/atomic_service_pilot/machine_audits/atomic/interaction_semantic_eval_report.json`
- Decoupled 机器审计：`output/experiments/plan3_20260725/atomic_service_pilot/machine_audits/decoupled/interaction_semantic_eval_report.json`
