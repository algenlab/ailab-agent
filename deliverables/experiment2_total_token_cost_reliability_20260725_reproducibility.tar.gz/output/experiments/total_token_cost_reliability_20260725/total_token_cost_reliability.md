# Total Token Cost-Reliability Curve

## 主要结果

| 方法/策略 | 总 tokens/题 | Machine OK | 模型调用/题 | API latency/题 |
|---|---:|---:|---:|---:|
| Direct + 最多 0 次修复 | 19,677.440 | 106/200 | 1.000 | 207.241 s |
| Direct + 最多 1 次修复 | 36,082.840 | 118/200 | 1.470 | 301.292 s |
| Direct + 最多 2 次修复 | 51,056.595 | 119/200 | 1.880 | 384.316 s |
| Direct + 最多 3 次修复 | 66,327.380 | 120/200 | 2.285 | 466.357 s |
| Direct + 最多 5 次修复 | 97,914.885 | 120/200 | 3.085 | 632.044 s |
| AlgoTutorGen selected-final | 76,847.165 | 198/200 | 5.330 | 573.940 s |
| AlgoTutorGen all-attempt | 84,352.785 | 198/200 | 5.755 | 629.222 s |

## 主比较

AlgoTutorGen all-attempt 的平均成本为 84,352.785 tokens/题。Direct 每题硬 cap=192,625 时，实际平均成本为 84,254.445 tokens/题，是冻结日志中最接近该目标的点；其 Machine OK 为 120/200。

配对差值按 AlgoTutorGen - Direct 定义，为 39.0 个百分点，95% paired-bootstrap CI [32.0, 46.0]，exact McNemar p=1.40786e-21。

## 口径说明

- token 为 API 返回的 prompt_tokens + completion_tokens；所有 617 次 Direct 调用 usage 均完整。
- 硬 cap 不允许纳入部分模型调用；初始调用是不可避免的已发生成本，即使它自身高于 cap 也计入。
- Machine OK 使用 best-so-far，因此后续失败页面不会让已经通过的任务退化。
- 84.4k 是 AlgoTutorGen 的平均成本，不等于 Direct 的逐题 84.4k 硬 cap。两者均在 JSON/CSV 中报告。
- API latency 与调用数独立汇总。旧日志没有独立的本地编译计时，selected-final 只能恢复非模型流水线残差。

## 结论边界

在冻结的 Direct 初始页、反馈器、整页重写策略和最多五次修复范围内，Direct 在更高平均 token 成本下仍未追上 AlgoTutorGen。这支持该测试预算范围内的结构化链路成本-可靠性优势，但不是对所有 browser repair 方法的严格因果结论。
